class Property {
  final int id;
  final String name;
  final String city;
  final String address;
  final int units;
  final int occupied;
  final int overdue;

  const Property({required this.id, required this.name, required this.city, required this.address, required this.units, required this.occupied, required this.overdue});

  double get occupancy => units == 0 ? 0 : occupied / units;
}
