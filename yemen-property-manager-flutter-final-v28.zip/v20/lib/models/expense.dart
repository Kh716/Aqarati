class Expense {
  final int id;
  final String title;
  final String property;
  final int amount;
  final String date;
  const Expense({required this.id, required this.title, required this.property, required this.amount, required this.date});
}
