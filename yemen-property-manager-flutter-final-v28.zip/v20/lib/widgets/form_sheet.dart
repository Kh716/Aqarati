import 'package:flutter/material.dart';

const kGold = Color(0xFFD9A45E);
const kPanel = Color(0xFF172738);
const kField = Color(0xFF1C3042);
const kMuted = Color(0xFF9DAAB7);

class FormSheet extends StatelessWidget {
  final String title;
  final String? subtitle;
  final IconData icon;
  final Widget child;
  final String saveLabel;
  final VoidCallback? onSave;
  final bool saving;

  const FormSheet({super.key, required this.title, this.subtitle, required this.icon, required this.child, required this.saveLabel, this.onSave, this.saving = false});

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.viewInsetsOf(context).bottom;
    return Material(
      color: Colors.transparent,
      child: SafeArea(
        top: false,
        child: Container(
          constraints: const BoxConstraints(maxHeight: 760),
          decoration: const BoxDecoration(color: kPanel, borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
          child: Padding(
            padding: EdgeInsets.fromLTRB(18, 10, 18, 14 + bottom),
            child: Column(children: [
              Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(10))),
              const SizedBox(height: 12),
              Row(textDirection: TextDirection.rtl, children: [
                Container(width: 44, height: 44, decoration: BoxDecoration(color: const Color(0x223A2D1E), borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: kGold)),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text(title, textAlign: TextAlign.right, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900)), if (subtitle != null) Text(subtitle!, textAlign: TextAlign.right, style: const TextStyle(color: kMuted, fontSize: 11))])),
                IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close_rounded, color: Colors.white70)),
              ]),
              const SizedBox(height: 10),
              Expanded(child: SingleChildScrollView(physics: const BouncingScrollPhysics(), keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag, child: child)),
              const SizedBox(height: 12),
              Row(textDirection: TextDirection.rtl, children: [
                Expanded(flex: 2, child: FilledButton.icon(onPressed: saving ? null : onSave, icon: saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.check_rounded), label: Text(saving ? 'جارٍ الحفظ...' : saveLabel), style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50), backgroundColor: kGold, foregroundColor: Colors.black))),
                const SizedBox(width: 10),
                Expanded(child: OutlinedButton(onPressed: saving ? null : () => Navigator.pop(context), style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(50), side: const BorderSide(color: Colors.white24)), child: const Text('إلغاء'))),
              ]),
            ]),
          ),
        ),
      ),
    );
  }
}

InputDecoration fieldDecoration(String label, {IconData? icon, String? hint}) => InputDecoration(
  labelText: label,
  hintText: hint,
  prefixIcon: icon == null ? null : Icon(icon, size: 20),
  filled: true,
  fillColor: kField,
  border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
  enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: Colors.white10)),
  focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: kGold, width: 1.2)),
  contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
);

class FormSection extends StatelessWidget {
  final String title;
  final Widget child;
  const FormSection({super.key, required this.title, required this.child});
  @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.only(bottom: 14), child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text(title, textAlign: TextAlign.right, style: const TextStyle(color: kGold, fontSize: 12, fontWeight: FontWeight.w800)), const SizedBox(height: 8), child]));
}

class FormHint extends StatelessWidget {
  final String text;
  const FormHint(this.text, {super.key});
  @override Widget build(BuildContext context) => Container(width: double.infinity, padding: const EdgeInsets.all(11), margin: const EdgeInsets.only(bottom: 12), decoration: BoxDecoration(color: const Color(0x121F2F40), borderRadius: BorderRadius.circular(12)), child: Text(text, textAlign: TextAlign.right, style: const TextStyle(color: kMuted, fontSize: 11)));
}
