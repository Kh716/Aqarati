import 'package:flutter/material.dart';
import '../models/property.dart';
import 'app_card.dart';

class PropertyCard extends StatelessWidget {
  final Property property;
  final VoidCallback? onDelete;
  final VoidCallback? onEdit;
  final VoidCallback? onOpen;
  const PropertyCard({super.key, required this.property, this.onDelete, this.onEdit, this.onOpen});

  @override
  Widget build(BuildContext context) {
    final pct = (property.occupancy * 100).round();
    return InkWell(onTap: onOpen, borderRadius: BorderRadius.circular(20), child: AppCard(
      child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        Row(children: [
          Container(width: 50, height: 50, decoration: BoxDecoration(color: const Color(0xFFFFE8C5), borderRadius: BorderRadius.circular(15)), child: const Icon(Icons.apartment_rounded, color: Color(0xFF9C6A28), size: 27)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text(property.name, textAlign: TextAlign.right, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)), const SizedBox(height: 3), Text('${property.city} • ${property.address}', textAlign: TextAlign.right, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Color(0xFF9DAAB7), fontSize: 11))])),
          if (onEdit != null) IconButton(onPressed: onEdit, icon: const Icon(Icons.edit_outlined, color: Color(0xFFD9A45E))),
          if (onDelete != null) IconButton(onPressed: onDelete, icon: const Icon(Icons.delete_outline, color: Color(0xFFE77777))),
        ]),
        const SizedBox(height: 16),
        Row(children: [
          _stat('الإشغال', '$pct%'),
          const SizedBox(width: 8),
          _stat('الوحدات', '${property.units} وحدة'),
          const SizedBox(width: 8),
          _stat('الشاغر', '${property.units - property.occupied}'),
        ]),
        const SizedBox(height: 14),
        Wrap(spacing: 6, runSpacing: 6, children: List.generate(property.units.clamp(0, 12), (i) => Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5), decoration: BoxDecoration(color: const Color(0xFF0E1A26), border: Border.all(color: i < property.occupied ? const Color(0xFF4B2530) : const Color(0xFF3C4B3B)), borderRadius: BorderRadius.circular(7)), child: Text('${101 + i}', style: TextStyle(fontSize: 10, color: i < property.occupied ? const Color(0xFFEE8888) : const Color(0xFF8ED39E))))),
      ]),
    ));
  }

  Widget _stat(String label, String value) => Expanded(child: Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: const Color(0xFF101D2A), borderRadius: BorderRadius.circular(12)), child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text(label, style: const TextStyle(color: Color(0xFF9DAAB7), fontSize: 10)), const SizedBox(height: 3), Text(value, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13))])));
}
