import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class LoginPage extends StatefulWidget {
  final VoidCallback onLoggedIn;
  const LoginPage({super.key, required this.onLoggedIn});
  @override State<LoginPage> createState() => _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final email=TextEditingController();
  final password=TextEditingController();
  bool busy=false, obscure=true;
  String? error;
  Future<void> login() async {
    if (email.text.trim().isEmpty || password.text.isEmpty) {
      setState(()=>error='أدخل البريد الإلكتروني وكلمة المرور.');
      return;
    }
    setState(()=>busy=true); error=null;
    try {
      final user=await AuthService.instance.login(email.text,password.text);
      if(!mounted)return;
      setState(()=>busy=false);
      if(user==null){setState(()=>error='البريد الإلكتروني أو كلمة المرور غير صحيحة، أو الحساب غير نشط.');return;}
      widget.onLoggedIn();
    } catch (_) {
      if (!mounted) return;
      setState(()=>busy=false);
      setState(()=>error='تعذر تسجيل الدخول بسبب خطأ داخلي. أعد المحاولة.');
    }
  }
  @override void dispose(){email.dispose();password.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(body:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:430),child:Card(child:Padding(padding:const EdgeInsets.all(24),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    const Icon(Icons.apartment_rounded,size:64,color:Color(0xFFD9A45E)), const SizedBox(height:12),
    const Text('مدير العقارات اليمني',textAlign:TextAlign.center,style:TextStyle(fontSize:26,fontWeight:FontWeight.w900)),
    const SizedBox(height:6), const Text('تسجيل الدخول إلى لوحة الإدارة',textAlign:TextAlign.center), const SizedBox(height:28),
    TextField(controller:email,keyboardType:TextInputType.emailAddress,textDirection:TextDirection.ltr,decoration:const InputDecoration(labelText:'البريد الإلكتروني',prefixIcon:Icon(Icons.email_outlined))),
    const SizedBox(height:14), TextField(controller:password,obscureText:obscure,textDirection:TextDirection.ltr,decoration:InputDecoration(labelText:'كلمة المرور',prefixIcon:const Icon(Icons.lock_outline),suffixIcon:IconButton(onPressed:()=>setState(()=>obscure=!obscure),icon:Icon(obscure?Icons.visibility_outlined:Icons.visibility_off_outlined)))),
    if(error!=null)...[const SizedBox(height:12),Text(error!,textAlign:TextAlign.right,style:const TextStyle(color:Colors.redAccent))],
    const SizedBox(height:22), FilledButton.icon(onPressed:busy?null:login,icon:busy?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.login),label:const Text('دخول')),
    const SizedBox(height:16), const Text('أدخل بيانات الحساب الذي أنشأه مسؤول النظام.',textAlign:TextAlign.center,style:TextStyle(fontSize:12,color:Colors.white54)),
  ])))))));
}
