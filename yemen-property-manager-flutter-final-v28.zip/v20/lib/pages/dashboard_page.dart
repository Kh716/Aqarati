import 'package:flutter/material.dart';
import '../app.dart';
import '../widgets/app_card.dart';

class DashboardPage extends StatefulWidget {
  final int refreshToken;
  const DashboardPage({super.key, this.refreshToken = 0});
  @override State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  bool loading = true;
  int properties = 0, units = 0, occupied = 0, tenants = 0, activeContracts = 0;
  int expected = 0, paid = 0, remaining = 0, overdueContracts = 0, revenues = 0, expenses = 0;
  List<Map<String, Object?>> recent = [], expiring = [], overdueRows = [], expiredRows = [];

  @override void initState() { super.initState(); _load(); }
  @override void didUpdateWidget(covariant DashboardPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.refreshToken != widget.refreshToken) _load();
  }

  Future<void> _load() async {
    if (mounted) setState(() => loading = true);
    final live = await db.livePortfolioSummary();
    final summary = await db.collectionSummary();
    final rev = await db.sum('revenues', 'amount');
    final exp = await db.sum('expenses', 'amount');
    final recentRows = await db.recentPayments();
    final expiringRows = await db.expiringContracts();
    final overdueRows = (await db.collectionBalances()).where((r) => r['is_overdue'] == true).toList();
    final expiredRows = await db.expiredContracts(limit: 5);
    if (!mounted) return;
    setState(() {
      properties = live['properties'] ?? 0;
      units = live['units'] ?? 0;
      occupied = live['occupied'] ?? 0;
      tenants = live['tenants'] ?? 0;
      activeContracts = live['activeContracts'] ?? 0;
      expected = summary['expected'] ?? 0;
      paid = summary['paid'] ?? 0;
      remaining = summary['remaining'] ?? 0;
      overdueContracts = summary['overdueContracts'] ?? 0;
      revenues = rev;
      expenses = exp;
      recent = recentRows;
      expiring = expiringRows;
      this.overdueRows = overdueRows;
      this.expiredRows = expiredRows;
      loading = false;
    });
  }

  String money(int v) => '${v.toString().replaceAllMapped(RegExp(r'(?=(\d{3})+(?!\d))'), (_) => ',')} ر.ي';
  String date(String? value) => value == null || value.isEmpty ? '-' : value;

  @override Widget build(BuildContext context) {
    final rate = units == 0 ? 0 : (occupied / units * 100).round();
    final net = revenues - expenses;
    return RefreshIndicator(
      onRefresh: _load,
      child: ListView(padding: const EdgeInsets.fromLTRB(16, 14, 16, 28), children: [
        Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: const [
            Text('لوحة التحكم', textAlign: TextAlign.right, style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
            SizedBox(height: 4),
            Text('بيانات مباشرة من قاعدة البيانات', textAlign: TextAlign.right, style: TextStyle(color: Color(0xFF98A7B5), fontSize: 12)),
          ])),
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh, color: Color(0xFFD9A45E))),
        ]),
        const SizedBox(height: 16),
        AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          const Text('صافي الدخل', style: TextStyle(color: Color(0xFF9DAAB7))),
          const SizedBox(height: 7), Text(money(net), style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
          const SizedBox(height: 14), Row(children: [Expanded(child: _mini('الإيرادات', money(revenues))), const SizedBox(width: 10), Expanded(child: _mini('المصروفات', money(expenses)))])
        ])),
        const SizedBox(height: 20),
        const Text('التحصيل والمتأخرات', textAlign: TextAlign.right, style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
        const SizedBox(height: 12),
        Row(children: [Expanded(child: MetricCard(title: 'المستحق', value: money(expected), helper: 'حسب العقود', icon: Icons.event_note, color: const Color(0xFFE0A33A))), const SizedBox(width: 10), Expanded(child: MetricCard(title: 'المقبوض', value: money(paid), helper: 'دفعات فعلية', icon: Icons.payments, color: const Color(0xFF7ACD9B)))]),
        const SizedBox(height: 10),
        Row(children: [Expanded(child: MetricCard(title: 'المتبقي', value: money(remaining), helper: 'يحتاج متابعة', icon: Icons.warning_rounded, color: const Color(0xFFE56B6F))), const SizedBox(width: 10), Expanded(child: MetricCard(title: 'عقود متأخرة', value: '$overdueContracts', helper: 'عليها رصيد', icon: Icons.receipt_long, color: const Color(0xFF70A6D9)))]),
        const SizedBox(height: 20),
        const Text('مؤشرات المحفظة', textAlign: TextAlign.right, style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
        const SizedBox(height: 12),
        Row(children: [Expanded(child: MetricCard(title: 'نسبة الإشغال', value: '$rate%', helper: '$occupied من $units وحدة', icon: Icons.pie_chart, color: const Color(0xFFE0A33A))), const SizedBox(width: 10), Expanded(child: MetricCard(title: 'العقارات', value: '$properties', helper: '$activeContracts عقد نشط', icon: Icons.apartment, color: const Color(0xFF70A6D9)))]),
        const SizedBox(height: 10),
        Row(children: [Expanded(child: MetricCard(title: 'الوحدات', value: '$units', helper: 'إجمالي الوحدات', icon: Icons.home_work_outlined, color: const Color(0xFF8FC7B5))), const SizedBox(width: 10), Expanded(child: MetricCard(title: 'المستأجرون', value: '$tenants', helper: 'سجلات المستأجرين', icon: Icons.people_outline, color: const Color(0xFFB58AD9)))]),
        const SizedBox(height: 22),
        _sectionTitle('التنبيهات والمتابعة'),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: _alertCard('متأخرات', '${overdueRows.length}', Icons.warning_amber_rounded, const Color(0xFFE47777))),
          const SizedBox(width: 10),
          Expanded(child: _alertCard('تنتهي قريبًا', '${expiring.length}', Icons.schedule, const Color(0xFFE0A33A))),
        ]),
        if (expiredRows.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: _alertCard('منتهية', '${expiredRows.length}', Icons.event_busy_outlined, const Color(0xFF9B8FD6))),
        const SizedBox(height: 22),
        _sectionTitle('آخر الدفعات'),
        const SizedBox(height: 10),
        if (recent.isEmpty) _empty('لا توجد دفعات مسجلة حتى الآن') else ...recent.map(_paymentTile),
        const SizedBox(height: 22),
        _sectionTitle('العقود القريبة من الانتهاء'),
        const SizedBox(height: 10),
        if (expiring.isEmpty) _empty('لا توجد عقود ستنتهي خلال 30 يومًا') else ...expiring.map(_contractTile),
        if (loading) const Padding(padding: EdgeInsets.all(22), child: Center(child: CircularProgressIndicator())),
      ]),
    );
  }

  Widget _sectionTitle(String text) => Row(children: [const Spacer(), Text(text, textAlign: TextAlign.right, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900))]);
  Widget _empty(String text) => AppCard(child: Text(text, textAlign: TextAlign.right, style: const TextStyle(color: Color(0xFF98A7B5))));
  Widget _paymentTile(Map<String, Object?> r) => AppCard(padding: const EdgeInsets.all(13), child: Row(children: [
    Text(money((r['amount'] as num?)?.toInt() ?? 0), style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF7ACD9B))),
    const Spacer(),
    Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text('${r['tenant_name'] ?? 'غير محدد'} • وحدة ${r['unit_number'] ?? '-'}', textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w800)), const SizedBox(height: 3), Text('${r['property_name'] ?? ''} • ${date(r['date']?.toString())}', textAlign: TextAlign.right, style: const TextStyle(color: Color(0xFF98A7B5), fontSize: 11))])
  ]));
  Widget _contractTile(Map<String, Object?> r) => AppCard(padding: const EdgeInsets.all(13), child: Row(children: [
    const Icon(Icons.schedule, color: Color(0xFFE0A33A)), const SizedBox(width: 10), Text(date(r['end_date']?.toString()), style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFFE0A33A))),
    const Spacer(), Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text('${r['tenant_name'] ?? 'غير محدد'} • وحدة ${r['unit_number'] ?? '-'}', textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w800)), const SizedBox(height: 3), Text('${r['property_name'] ?? ''}', textAlign: TextAlign.right, style: const TextStyle(color: Color(0xFF98A7B5), fontSize: 11))])
  ]));
  Widget _alertCard(String title, String value, IconData icon, Color color) => AppCard(padding: const EdgeInsets.all(13), child: Row(children: [
    Icon(icon, color: color, size: 25), const Spacer(),
    Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: color)), Text(title, style: const TextStyle(color: Color(0xFF9DAAB7), fontSize: 11))])
  ]));

  Widget _mini(String a, String b) => Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: const Color(0xFF213447), borderRadius: BorderRadius.circular(13)), child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text(a, style: const TextStyle(color: Color(0xFF9DAAB7), fontSize: 11)), const SizedBox(height: 4), Text(b, style: const TextStyle(fontWeight: FontWeight.w800))]));
}
