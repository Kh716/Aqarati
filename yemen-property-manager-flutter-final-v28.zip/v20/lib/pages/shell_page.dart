import 'package:flutter/material.dart';
import 'dashboard_page.dart'; import 'properties_page.dart'; import 'expenses_page.dart'; import 'tenants_page.dart'; import 'contracts_page.dart'; import 'payments_page.dart'; import 'revenues_page.dart'; import 'reports_page.dart'; import 'settings_page.dart'; import 'notifications_page.dart'; import 'users_page.dart'; import 'maintenance_page.dart';
import '../services/auth_service.dart';

class ShellPage extends StatefulWidget{final Map<String,Object?> user;final VoidCallback onLogout;const ShellPage({super.key,required this.user,required this.onLogout});@override State<ShellPage> createState()=>_ShellPageState();}
class _ShellPageState extends State<ShellPage>{int index=0;int dashboardRefresh=0;String get role=>'${widget.user['role']}';final auth=AuthService.instance;
 List<Widget> get pages=>[DashboardPage(refreshToken:dashboardRefresh),const PropertiesPage(),const TenantsPage(),const ExpensesPage()];
 bool can(String p)=>auth.can(role,p);
 Future<void> open(Widget page)async{await Navigator.of(context).push(MaterialPageRoute(builder:(_)=>page));if(mounted&&index==0)setState(()=>dashboardRefresh++);}
 void denied(){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('ليس لديك صلاحية للوصول إلى هذه الصفحة.')));}
 Widget item(String t,IconData i,String perm,Widget page)=>ListTile(leading:Icon(i,color:const Color(0xFFD9A45E)),title:Text(t,textAlign:TextAlign.right),onTap:(){Navigator.pop(context);if(can(perm))open(page);else denied();});
 @override Widget build(BuildContext context)=>Scaffold(
  drawer:Drawer(backgroundColor:const Color(0xFF111D29),child:SafeArea(child:ListView(padding:const EdgeInsets.symmetric(vertical:16),children:[
   const Padding(padding:EdgeInsets.all(20),child:Text('مدير العقارات اليمني',textAlign:TextAlign.right,style:TextStyle(fontSize:20,fontWeight:FontWeight.w900,color:Color(0xFFD9A45E)))),
   Padding(padding:const EdgeInsets.fromLTRB(20,0,20,14),child:Column(crossAxisAlignment:CrossAxisAlignment.end,children:[Text('${widget.user['name']}',style:const TextStyle(fontWeight:FontWeight.bold)),Text('$role',style:const TextStyle(color:Colors.white60,fontSize:12))])),
   item('العقود',Icons.description_outlined,'contracts_view',const ContractsPage()),item('الدفعات والتحصيل',Icons.payments_outlined,'payments',const PaymentsPage()),item('الإيرادات',Icons.trending_up,'revenues',const RevenuesPage()),item('إدارة الصيانة',Icons.build_outlined,'maintenance',const MaintenancePage()),item('التنبيهات والمتابعة',Icons.notifications_active_outlined,'notifications',const NotificationsPage()),item('التقارير',Icons.assessment_outlined,'reports',const ReportsPage()),
   if(role=='مدير النظام') item('المستخدمون والصلاحيات',Icons.admin_panel_settings_outlined,'users',const UsersPage()),item('الإعدادات',Icons.settings_outlined,'settings',const SettingsPage()),
   const Divider(),ListTile(leading:const Icon(Icons.logout,color:Colors.redAccent),title:const Text('تسجيل الخروج',textAlign:TextAlign.right),onTap:()async{Navigator.pop(context);final yes=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('تسجيل الخروج'),content:const Text('هل تريد تسجيل الخروج من الحساب؟'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('خروج'))]));if(yes==true)widget.onLogout();})
  ]))),
  appBar:AppBar(title:Text(['لوحة التحكم','العقارات','المستأجرون','المصروفات'][index],style:const TextStyle(fontWeight:FontWeight.w800)),backgroundColor:const Color(0xFF0C1621),surfaceTintColor:Colors.transparent),
  body:SafeArea(child:pages[index]),bottomNavigationBar:NavigationBar(backgroundColor:const Color(0xFF111D29),indicatorColor:const Color(0xFF3A2D1E),selectedIndex:index,onDestinationSelected:(i)=>setState((){if(i==3&&!can('expenses')){denied();return;}if(i==1&&!can('properties_view')){denied();return;}if(i==2&&!can('tenants_view')){denied();return;}if(i==0&&!can('dashboard')){denied();return;}index=i;if(i==0)dashboardRefresh++;}),destinations:const [NavigationDestination(icon:Icon(Icons.dashboard_outlined),selectedIcon:Icon(Icons.dashboard),label:'الرئيسية'),NavigationDestination(icon:Icon(Icons.apartment_outlined),selectedIcon:Icon(Icons.apartment),label:'العقارات'),NavigationDestination(icon:Icon(Icons.people_outline),selectedIcon:Icon(Icons.people),label:'المستأجرون'),NavigationDestination(icon:Icon(Icons.receipt_long_outlined),selectedIcon:Icon(Icons.receipt_long),label:'المصروفات')]),
 );
}
