import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/database_service.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  bool _busy = false;
  String _lastBackup = 'لم يتم إنشاء نسخة احتياطية بعد';
  final TextEditingController _establishmentName = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadLastBackup();
    _loadEstablishmentName();
  }

  Future<void> _loadLastBackup() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() => _lastBackup = prefs.getString('last_backup_at') ?? 'لم يتم إنشاء نسخة احتياطية بعد');
  }


  Future<void> _loadEstablishmentName() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    _establishmentName.text = prefs.getString('establishment_name') ?? '';
  }

  Future<void> _saveEstablishmentName() async {
    final name = _establishmentName.text.trim();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('establishment_name', name);
    if (mounted) _message(name.isEmpty ? 'تم حذف اسم المنشأة.' : 'تم حفظ اسم المنشأة بنجاح.');
  }

  @override
  void dispose() {
    _establishmentName.dispose();
    super.dispose();
  }

  Future<void> _backup({bool share = false}) async {
    setState(() => _busy = true);
    try {
      final path = await DatabaseService.instance.createBackupFile();
      final now = DateTime.now();
      final text = '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')} ${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('last_backup_at', text);
      if (mounted) setState(() => _lastBackup = text);
      if (share) {
        await Share.shareXFiles([XFile(path)], text: 'نسخة احتياطية من مدير العقارات اليمني');
      }
      if (mounted) _message('تم إنشاء النسخة الاحتياطية بنجاح.');
    } catch (e) {
      if (mounted) _message('تعذر إنشاء النسخة الاحتياطية: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _restore() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['db'],
      withData: false,
    );
    final path = result?.files.single.path;
    if (path == null || path.isEmpty || !mounted) return;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('تأكيد الاستعادة', textAlign: TextAlign.right),
        content: const Text(
          'سيتم استبدال قاعدة البيانات الحالية بالنسخة المحددة. يُنصح بإنشاء نسخة احتياطية حالية أولًا. هل تريد المتابعة؟',
          textAlign: TextAlign.right,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('استعادة')),
        ],
      ),
    );
    if (confirmed != true) return;

    setState(() => _busy = true);
    try {
      await DatabaseService.instance.restoreBackupFile(path);
      if (mounted) _message('تمت استعادة النسخة الاحتياطية بنجاح.');
    } catch (e) {
      if (mounted) _message('تعذر استعادة النسخة: $e', error: true);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _message(String text, {bool error = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text, textAlign: TextAlign.right), backgroundColor: error ? Colors.red : null));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: Stack(
        children: [
          ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const ListTile(
                leading: Icon(Icons.language),
                title: Text('لغة التطبيق', textAlign: TextAlign.right),
                subtitle: Text('العربية - RTL', textAlign: TextAlign.right),
              ),
              const Divider(),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    const Text('بيانات المنشأة', textAlign: TextAlign.right, style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    TextField(controller: _establishmentName, textAlign: TextAlign.right, decoration: const InputDecoration(labelText: 'اسم المنشأة أو مالك العقار', hintText: 'يظهر في إيصالات الدفع')),
                    const SizedBox(height: 10),
                    FilledButton.icon(onPressed: _busy ? null : _saveEstablishmentName, icon: const Icon(Icons.save_outlined), label: const Text('حفظ بيانات المنشأة')),
                  ]),
                ),
              ),
              const Divider(),
              const ListTile(
                leading: Icon(Icons.currency_exchange),
                title: Text('العملة', textAlign: TextAlign.right),
                subtitle: Text('الريال اليمني (ر.ي)', textAlign: TextAlign.right),
              ),
              const Divider(),
              const ListTile(
                leading: Icon(Icons.security),
                title: Text('أمان البيانات', textAlign: TextAlign.right),
                subtitle: Text('قاعدة بيانات محلية SQLite', textAlign: TextAlign.right),
              ),
              const SizedBox(height: 12),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Text('النسخ الاحتياطي والاستعادة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold), textAlign: TextAlign.right),
                      const SizedBox(height: 8),
                      Text('آخر نسخة: $_lastBackup', textAlign: TextAlign.right),
                      const SizedBox(height: 14),
                      FilledButton.icon(
                        onPressed: _busy ? null : () => _backup(),
                        icon: const Icon(Icons.backup_rounded),
                        label: const Text('إنشاء نسخة احتياطية'),
                      ),
                      const SizedBox(height: 10),
                      OutlinedButton.icon(
                        onPressed: _busy ? null : () => _backup(share: true),
                        icon: const Icon(Icons.share_rounded),
                        label: const Text('إنشاء ومشاركة النسخة'),
                      ),
                      const SizedBox(height: 10),
                      OutlinedButton.icon(
                        onPressed: _busy ? null : _restore,
                        icon: const Icon(Icons.restore_rounded),
                        label: const Text('استعادة نسخة احتياطية'),
                      ),
                      const SizedBox(height: 8),
                      const Text('احتفظ بالنسخة الاحتياطية في مكان آمن قبل نقل التطبيق أو إعادة تثبيته.', textAlign: TextAlign.right, style: TextStyle(fontSize: 12)),
                    ],
                  ),
                ),
              ),
            ],
          ),
          if (_busy) const ColoredBox(color: Color(0x66000000), child: Center(child: CircularProgressIndicator())),
        ],
      ),
    );
  }
}
