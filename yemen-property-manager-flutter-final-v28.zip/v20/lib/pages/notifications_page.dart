import 'package:flutter/material.dart';
import '../app.dart';
import '../widgets/app_card.dart';
import 'contract_details_page.dart';

class NotificationsPage extends StatefulWidget {
  const NotificationsPage({super.key});
  @override State<NotificationsPage> createState() => _NotificationsPageState();
}

class _NotificationsPageState extends State<NotificationsPage> {
  bool loading = true;
  List<Map<String, Object?>> overdue = [];
  List<Map<String, Object?>> expiring = [];
  List<Map<String, Object?>> expired = [];
  List<Map<String, Object?>> maintenance = [];

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => loading = true);
    final balances = await db.collectionBalances();
    final near = await db.expiringContracts(days: 30, limit: 100);
    final old = await db.expiredContracts(limit: 100);
    final repairs = await db.maintenanceRequests();
    if (!mounted) return;
    setState(() {
      overdue = balances.where((r) => r['is_overdue'] == true).toList();
      expiring = near;
      expired = old;
      maintenance = repairs.where((r) => r['status'] == 'جديد' || r['status'] == 'قيد التنفيذ').toList();
      loading = false;
    });
  }

  String money(Object? value) => '${((value as num?)?.toInt() ?? 0).toString().replaceAllMapped(RegExp(r'(?=(\d{3})+(?!\d))'), (_) => ',')} ر.ي';

  @override
  Widget build(BuildContext context) {
    final total = overdue.length + expiring.length + expired.length + maintenance.length;
    return Scaffold(
      appBar: AppBar(title: const Text('التنبيهات والمتابعة')), 
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: const EdgeInsets.all(16), children: [
          AppCard(child: Row(children: [
            const Icon(Icons.notifications_active_outlined, color: Color(0xFFD9A45E), size: 30),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              const Text('المتابعات المطلوبة', textAlign: TextAlign.right, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              const SizedBox(height: 3),
              Text('$total تنبيه حالي', textAlign: TextAlign.right, style: const TextStyle(color: Color(0xFF9DAAB7))),
            ])),
            IconButton(onPressed: _load, icon: const Icon(Icons.refresh, color: Color(0xFFD9A45E))),
          ])),
          const SizedBox(height: 18),
          _header('المتأخرات', overdue.length, Icons.warning_amber_rounded, const Color(0xFFE47777)),
          const SizedBox(height: 9),
          if (overdue.isEmpty) _empty('لا توجد عقود عليها متأخرات.') else ...overdue.map(_overdueCard),
          const SizedBox(height: 20),
          _header('العقود القريبة من الانتهاء', expiring.length, Icons.schedule, const Color(0xFFE0A33A)),
          const SizedBox(height: 9),
          if (expiring.isEmpty) _empty('لا توجد عقود ستنتهي خلال 30 يومًا.') else ...expiring.map((r) => _contractCard(r, false)),
          const SizedBox(height: 20),
          _header('العقود المنتهية', expired.length, Icons.event_busy_outlined, const Color(0xFF9B8FD6)),
          const SizedBox(height: 9),
          if (expired.isEmpty) _empty('لا توجد عقود منتهية.') else ...expired.map((r) => _contractCard(r, true)),
          const SizedBox(height: 20),
          _header('طلبات الصيانة المفتوحة', maintenance.length, Icons.build_outlined, const Color(0xFFE0A33A)),
          const SizedBox(height: 9),
          if (maintenance.isEmpty) _empty('لا توجد طلبات صيانة مفتوحة.') else ...maintenance.map(_maintenanceCard),
          if (loading) const Padding(padding: EdgeInsets.all(30), child: Center(child: CircularProgressIndicator())),
        ]),
      ),
    );
  }

  Widget _header(String title, int count, IconData icon, Color color) => Row(children: [
    Container(padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5), decoration: BoxDecoration(color: color.withOpacity(.14), borderRadius: BorderRadius.circular(10)), child: Text('$count', style: TextStyle(color: color, fontWeight: FontWeight.w900))),
    const Spacer(), Icon(icon, color: color), const SizedBox(width: 7), Text(title, textAlign: TextAlign.right, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
  ]);

  Widget _overdueCard(Map<String, Object?> r) => Padding(
    padding: const EdgeInsets.only(bottom: 9),
    child: AppCard(child: Row(children: [
      Text(money(r['remaining']), style: const TextStyle(color: Color(0xFFE47777), fontWeight: FontWeight.w900)),
      const Spacer(),
      Expanded(flex: 2, child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        Text('${r['tenant_name'] ?? 'غير محدد'} • وحدة ${r['unit_number'] ?? '-'}', textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 3), Text('${r['property_name'] ?? '-'} • عقد ${r['id']}', textAlign: TextAlign.right, style: const TextStyle(color: Color(0xFF9DAAB7), fontSize: 11)),
      ])),
      IconButton(onPressed: () => _open(r['id'] as int), icon: const Icon(Icons.chevron_left)),
    ])),
  );

  Widget _contractCard(Map<String, Object?> r, bool isExpired) => Padding(
    padding: const EdgeInsets.only(bottom: 9),
    child: AppCard(child: Row(children: [
      Text('${r['end_date'] ?? '-'}', style: TextStyle(color: isExpired ? const Color(0xFF9B8FD6) : const Color(0xFFE0A33A), fontWeight: FontWeight.w900, fontSize: 12)),
      const Spacer(),
      Expanded(flex: 2, child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        Text('${r['tenant_name'] ?? 'غير محدد'} • وحدة ${r['unit_number'] ?? '-'}', textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 3), Text('${r['property_name'] ?? '-'} • عقد ${r['id']}', textAlign: TextAlign.right, style: const TextStyle(color: Color(0xFF9DAAB7), fontSize: 11)),
      ])),
      IconButton(onPressed: () => _open(r['id'] as int), icon: const Icon(Icons.chevron_left)),
    ])),
  );

  Widget _maintenanceCard(Map<String,Object?> r) => Padding(
    padding: const EdgeInsets.only(bottom: 9),
    child: AppCard(child: Row(children: [
      Text('${r['status']}', style: const TextStyle(color: Color(0xFFE0A33A), fontWeight: FontWeight.w900, fontSize: 12)),
      const Spacer(),
      Expanded(flex: 3, child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        Text('${r['title']}', textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 3), Text('${r['property_name'] ?? '-'} • ${r['category']}', textAlign: TextAlign.right, style: const TextStyle(color: Color(0xFF9DAAB7), fontSize: 11)),
      ])),
    ])),
  );

  Widget _empty(String text) => AppCard(child: Text(text, textAlign: TextAlign.right, style: const TextStyle(color: Color(0xFF9DAAB7))));

  Future<void> _open(int id) async { await Navigator.push(context, MaterialPageRoute(builder: (_) => ContractDetailsPage(contractId: id))); _load(); }
}
