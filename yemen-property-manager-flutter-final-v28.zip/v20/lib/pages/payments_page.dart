import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:typed_data';
import 'package:share_plus/share_plus.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';
import '../app.dart';
import '../widgets/app_card.dart';

class PaymentsPage extends StatefulWidget {
  const PaymentsPage({super.key});
  @override State<PaymentsPage> createState() => _PaymentsPageState();
}

class _PaymentsPageState extends State<PaymentsPage> {
  List<Map<String,Object?>> rows=[];
  List<Map<String,Object?>> contracts=[];
  List<Map<String,Object?>> balances=[];

  @override void initState(){super.initState();load();}

  Future<void> load() async {
    final r=await db.paymentLedger();
    final c=await db.contracts();
    final b=await db.collectionBalances();
    if(mounted)setState((){rows=r;contracts=c;balances=b;});
  }

  Map<String,Object?>? balanceFor(int id){
    for(final r in balances){if(r['id']==id)return r;}
    return null;
  }

  String money(Object? v)=>'${v ?? 0} ر.ي';

  @override Widget build(BuildContext c)=>Scaffold(
    appBar:AppBar(title:const Text('الدفعات والتحصيل')),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      Row(children:[
        const Expanded(child:Text('سجل الدفعات',textAlign:TextAlign.right,style:TextStyle(fontSize:23,fontWeight:FontWeight.w900))),
        FilledButton.icon(onPressed:contracts.isEmpty?null:add,icon:const Icon(Icons.add),label:const Text('دفعة جديدة'))
      ]),
      const SizedBox(height:14),
      if(balances.isNotEmpty)...[
        Row(children:[
          Expanded(child:_summary('المستحق',balances.fold<int>(0,(s,r)=>s+((r['expected'] as int?)??0)),const Color(0xFFD9A45E))),
          const SizedBox(width:8),
          Expanded(child:_summary('المقبوض',balances.fold<int>(0,(s,r)=>s+((r['paid'] as int?)??0)),const Color(0xFF7ACD9B))),
          const SizedBox(width:8),
          Expanded(child:_summary('المتبقي',balances.fold<int>(0,(s,r)=>s+((r['remaining'] as int?)??0)),const Color(0xFFE47777))),
        ]),
        const SizedBox(height:16),
      ],
      if(rows.isEmpty)const AppCard(child:Text('لا توجد دفعات مسجلة حاليًا.',textAlign:TextAlign.right,style:TextStyle(color:Color(0xFF9DAAB7))))
      else ...rows.map((r)=>Padding(
        padding:const EdgeInsets.only(bottom:10),
        child:AppCard(child:Row(children:[
          const Icon(Icons.payments,color:Color(0xFF7ACD9B)),const SizedBox(width:10),
          Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.end,children:[
            Text('${r['amount']} ر.ي',textAlign:TextAlign.right,style:const TextStyle(fontWeight:FontWeight.w900)),
            Text('${r['tenant_name'] ?? 'مستأجر'} • وحدة ${r['unit_number'] ?? '-'}',textAlign:TextAlign.right,style:const TextStyle(fontSize:12)),
            Text('${r['period']} • ${r['method']} • ${r['date']}',textAlign:TextAlign.right,style:const TextStyle(color:Color(0xFF9DAAB7),fontSize:11)),
          ])),
          IconButton(tooltip:'مشاركة الإيصال PDF',onPressed:()=>_share(r),icon:const Icon(Icons.share_outlined,color:Color(0xFFD9A45E))),
          IconButton(tooltip:'معاينة الإيصال PDF',onPressed:()=>_previewReceipt(r),icon:const Icon(Icons.picture_as_pdf_outlined,color:Color(0xFF7ACD9B))),
          IconButton(onPressed:()=>_delete(r),icon:const Icon(Icons.delete_outline,color:Color(0xFFE47777))),
        ])),
      )),
    ]));

  Widget _summary(String title,int value,Color color)=>Container(
    padding:const EdgeInsets.all(12),
    decoration:BoxDecoration(color:const Color(0xFF172738),borderRadius:BorderRadius.circular(14)),
    child:Column(children:[Text(title,style:TextStyle(color:color,fontSize:11)),const SizedBox(height:4),Text('${value} ر.ي',textAlign:TextAlign.center,style:const TextStyle(fontSize:12,fontWeight:FontWeight.w900))]),
  );

  Future<void> _delete(Map<String,Object?> r)async{
    final ok=await showDialog<bool>(context:context,builder:(x)=>AlertDialog(title:const Text('حذف الدفعة'),content:const Text('سيتم حذف الدفعة وإعادة احتساب المتبقي على العقد.'),actions:[TextButton(onPressed:()=>Navigator.pop(x,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(x,true),child:const Text('حذف'))]));
    if(ok==true){await db.deletePayment(r['id'] as int);load();}
  }

  Future<Uint8List> _receiptBytes(Map<String,Object?> r) async {
    final regularData = await rootBundle.load('assets/fonts/NotoKufiArabic-Regular.ttf');
    final boldData = await rootBundle.load('assets/fonts/NotoKufiArabic-Bold.ttf');
    final regular = pw.Font.ttf(regularData);
    final bold = pw.Font.ttf(boldData);
    final prefs = await SharedPreferences.getInstance();
    final establishment = prefs.getString('establishment_name')?.trim();
    final doc = pw.Document();
    doc.addPage(pw.Page(
      pageFormat: PdfPageFormat.a4,
      theme: pw.ThemeData.withFont(base: regular, bold: bold),
      build: (_) => pw.Directionality(
        textDirection: pw.TextDirection.rtl,
        child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.stretch, children: [
          pw.Center(child: pw.Text(establishment?.isNotEmpty == true ? establishment! : 'مدير العقارات اليمني', style: pw.TextStyle(font: bold, fontSize: 20))),
          pw.SizedBox(height: 5),
          pw.Center(child: pw.Text('إيصال استلام دفعة إيجار', style: pw.TextStyle(font: bold, fontSize: 16))),
          pw.SizedBox(height: 18),
          pw.Divider(),
          _receiptLine('رقم الإيصال', '${r['id'] ?? '-'}', regular, bold),
          _receiptLine('اسم المستأجر', '${r['tenant_name'] ?? '-'}', regular, bold),
          _receiptLine('العقار', '${r['property_name'] ?? '-'}', regular, bold),
          _receiptLine('رقم الوحدة', '${r['unit_number'] ?? '-'}', regular, bold),
          _receiptLine('المبلغ المستلم', '${r['amount'] ?? 0} ريال يمني', regular, bold),
          _receiptLine('الفترة المغطاة', '${r['period'] ?? '-'}', regular, bold),
          _receiptLine('طريقة الدفع', '${r['method'] ?? '-'}', regular, bold),
          _receiptLine('تاريخ الدفع', '${r['date'] ?? '-'}', regular, bold),
          pw.SizedBox(height: 18),
          pw.Text('تم استلام المبلغ الموضح أعلاه مقابل الفترة المذكورة.', style: pw.TextStyle(font: regular, fontSize: 11)),
          pw.Spacer(),
          pw.Row(textDirection: pw.TextDirection.rtl, mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
            pw.Text('توقيع المستلم: __________________', style: pw.TextStyle(font: regular, fontSize: 10)),
            pw.Text('الختم: __________________', style: pw.TextStyle(font: regular, fontSize: 10)),
          ]),
          pw.SizedBox(height: 12),
          pw.Center(child: pw.Text('هذا الإيصال صادر من تطبيق مدير العقارات اليمني', style: pw.TextStyle(font: regular, fontSize: 8))),
        ]),
      ),
    ));
    return doc.save();
  }

  pw.Widget _receiptLine(String label, String value, pw.Font regular, pw.Font bold) => pw.Container(
    padding: const pw.EdgeInsets.symmetric(vertical: 9, horizontal: 8),
    decoration: const pw.BoxDecoration(border: pw.Border(bottom: pw.BorderSide(color: PdfColors.grey300, width: .5))),
    child: pw.Row(textDirection: pw.TextDirection.rtl, children: [
      pw.SizedBox(width: 120, child: pw.Text(label, style: pw.TextStyle(font: bold, fontSize: 11))),
      pw.Expanded(child: pw.Text(value, style: pw.TextStyle(font: regular, fontSize: 11))),
    ]),
  );

  Future<void> _previewReceipt(Map<String,Object?> r) async {
    try {
      final bytes = await _receiptBytes(r);
      if (!mounted) return;
      await showDialog<void>(context: context, builder: (dialogContext) => Dialog(
        child: SizedBox(width: 760, height: 680, child: Column(children: [
          AppBar(title: const Text('معاينة إيصال الدفع'), automaticallyImplyLeading: false, actions: [IconButton(onPressed:()=>Navigator.pop(dialogContext), icon:const Icon(Icons.close))]),
          Expanded(child: PdfPreview(build: (_) async => bytes, allowPrinting: true, allowSharing: false, canChangePageFormat: false, canChangeOrientation: false)),
          Padding(padding: const EdgeInsets.all(10), child: FilledButton.icon(onPressed: () async { Navigator.pop(dialogContext); await _share(r); }, icon: const Icon(Icons.share), label: const Text('مشاركة ملف الإيصال PDF'))),
        ])),
      ));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذر إنشاء معاينة الإيصال: $e')));
    }
  }

  Future<void> _share(Map<String,Object?> r) async {
    try {
      final bytes = await _receiptBytes(r);
      final tempDir = await Directory.systemTemp.createTemp('yemen_property_receipt_');
      final file = File('${tempDir.path}/receipt_${r['id'] ?? DateTime.now().millisecondsSinceEpoch}.pdf');
      await file.writeAsBytes(bytes, flush: true);
      await Share.shareXFiles([XFile(file.path)], text: 'إيصال دفع إيجار - ${r['tenant_name'] ?? 'المستأجر'}');
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('تعذرت مشاركة الإيصال: $e')));
    }
  }

  Future<void> add()async{
    int? id=contracts.first['id'] as int?;
    final a=TextEditingController(text:'45000'),period=TextEditingController(text:'أكتوبر 2026'),method=TextEditingController(text:'نقدي');
    String? error;
    await showDialog(context:context,builder:(x)=>StatefulBuilder(builder:(x,set)=>AlertDialog(
      title:const Text('تسجيل دفعة'),
      content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
        DropdownButtonFormField<int>(value:id,decoration:const InputDecoration(labelText:'العقد'),items:contracts.map((r){final b=balanceFor(r['id'] as int);return DropdownMenuItem(value:r['id'] as int,child:Text('عقد ${r['id']} • متبقي ${b?['remaining'] ?? 0} ر.ي'));}).toList(),onChanged:(v)=>set(()=>id=v)),
        TextField(controller:a,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'المبلغ')),
        TextField(controller:period,textDirection:TextDirection.rtl,decoration:const InputDecoration(labelText:'الفترة')),
        TextField(controller:method,textDirection:TextDirection.rtl,decoration:const InputDecoration(labelText:'طريقة الدفع')),
        if(error!=null)Padding(padding:const EdgeInsets.only(top:10),child:Text(error!,textAlign:TextAlign.right,style:const TextStyle(color:Color(0xFFE47777))))
      ])),
      actions:[TextButton(onPressed:()=>Navigator.pop(x),child:const Text('إلغاء')),FilledButton(onPressed:()async{
        if(id==null){set(()=>error='اختر العقد أولًا.');return;}
        final msg=await db.addPayment(contractId:id!,amount:int.tryParse(a.text)??0,period:period.text.trim(),method:method.text.trim());
        if(msg!=null){set(()=>error=msg);return;}
        if(x.mounted)Navigator.pop(x);load();
      },child:const Text('حفظ'))]
    )));
  }
}
