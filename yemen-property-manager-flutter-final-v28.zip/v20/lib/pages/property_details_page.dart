import 'package:flutter/material.dart';
import '../app.dart';
import '../models/property.dart';

class PropertyDetailsPage extends StatefulWidget {
  final Property property;
  const PropertyDetailsPage({super.key, required this.property});
  @override State<PropertyDetailsPage> createState() => _PropertyDetailsPageState();
}

class _PropertyDetailsPageState extends State<PropertyDetailsPage> {
  List<Map<String,Object?>> units = [];
  bool loading = true;

  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    setState(() => loading = true);
    final rows = await db.propertyUnits(widget.property.id);
    if (!mounted) return;
    setState(() { units = rows; loading = false; });
  }

  @override Widget build(BuildContext context) {
    final occupied = units.where((u) => u['status'] == 'مؤجرة').length;
    final vacant = units.length - occupied;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.property.name, style: const TextStyle(fontWeight: FontWeight.w800)),
        actions: [IconButton(onPressed: () => _unitForm(), icon: const Icon(Icons.add_box_outlined))],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(padding: const EdgeInsets.fromLTRB(16,14,16,28), children: [
          _header(occupied, vacant),
          const SizedBox(height: 18),
          Row(children: [
            const Expanded(child: Text('الوحدات', textAlign: TextAlign.right, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900))),
            OutlinedButton.icon(onPressed: () => _unitForm(), icon: const Icon(Icons.add), label: const Text('إضافة وحدة')),
          ]),
          const SizedBox(height: 10),
          if (loading) const Center(child: Padding(padding: EdgeInsets.all(30), child: CircularProgressIndicator()))
          else if (units.isEmpty) _empty()
          else ...units.map(_unitCard),
        ]),
      ),
    );
  }

  Widget _header(int occupied, int vacant) => Container(
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(color: const Color(0xFF172738), borderRadius: BorderRadius.circular(22), border: Border.all(color: const Color(0xFF2A3A4A))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
      Text(widget.property.city, style: const TextStyle(color: Color(0xFFD9A45E), fontWeight: FontWeight.w800)),
      const SizedBox(height: 4), Text(widget.property.address, textAlign: TextAlign.right, style: const TextStyle(color: Color(0xFF9DAAB7))),
      const SizedBox(height: 16), Row(children: [_metric('الوحدات', '${units.length}'), const SizedBox(width: 8), _metric('مؤجرة', '$occupied'), const SizedBox(width: 8), _metric('شاغرة', '$vacant')]),
    ]),
  );

  Widget _metric(String title, String value) => Expanded(child: Container(
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(color: const Color(0xFF0E1A26), borderRadius: BorderRadius.circular(14)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text(title, style: const TextStyle(color: Color(0xFF9DAAB7), fontSize: 11)), const SizedBox(height: 4), Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900))]),
  ));

  Widget _unitCard(Map<String,Object?> u) {
    final rented = u['status'] == 'مؤجرة';
    final tenant = (u['tenant_name'] ?? '').toString();
    final rent = ((u['contract_rent'] ?? u['rent'] ?? 0) as num).toInt();
    return Card(
      color: const Color(0xFF172738), margin: const EdgeInsets.only(bottom: 10),
      child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        Row(children: [
          Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), decoration: BoxDecoration(color: rented ? const Color(0xFF432B32) : const Color(0xFF203D31), borderRadius: BorderRadius.circular(10)), child: Text(rented ? 'مؤجرة' : 'شاغرة', style: TextStyle(color: rented ? const Color(0xFFFF9B9B) : const Color(0xFF9CE0B0), fontWeight: FontWeight.w800))),
          const Spacer(),
          IconButton(onPressed: () => _unitForm(existing: u), icon: const Icon(Icons.edit_outlined, color: Color(0xFFD9A45E))),
          IconButton(onPressed: () => _deleteUnit(u), icon: const Icon(Icons.delete_outline, color: Color(0xFFE47777))),
          Text('وحدة ${u['number']}', style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
        ]),
        const SizedBox(height: 8),
        _line('الإيجار', '${_money(rent)} ر.ي'),
        if (rented) ...[
          _line('المستأجر', tenant.isEmpty ? 'غير محدد' : tenant),
          _line('العقد', (u['contract_status'] ?? 'نشط').toString()),
          if ((u['start_date'] ?? '').toString().isNotEmpty) _line('الفترة', '${u['start_date']} إلى ${u['end_date']}'),
        ] else _line('الحالة', 'يمكن إضافة عقد جديد لهذه الوحدة'),
      ]),
    );
  }

  Widget _line(String a, String b) => Padding(padding: const EdgeInsets.only(top: 5), child: Row(children: [Expanded(child: Text(b, textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w700))), Text(a, style: const TextStyle(color: Color(0xFF9DAAB7), fontSize: 12))]));
  String _money(int value) => value.toString().replaceAllMapped(RegExp(r'(?=(\d{3})+(?!\d))'), (_) => ',');
  Widget _empty() => const Padding(padding: EdgeInsets.all(30), child: Text('لا توجد وحدات في هذه العمارة', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFF9DAAB7))));

  Future<void> _unitForm({Map<String,Object?>? existing}) async {
    final number = TextEditingController(text: '${existing?['number'] ?? (101 + units.length)}');
    final rent = TextEditingController(text: '${existing?['rent'] ?? 0}');
    String? error;
    await showDialog(context: context, builder: (dialogContext) => StatefulBuilder(builder: (dialogContext, set) => AlertDialog(
      title: Text(existing == null ? 'إضافة وحدة' : 'تعديل الوحدة'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: number, textDirection: TextDirection.rtl, decoration: const InputDecoration(labelText: 'رقم الوحدة')),
        TextField(controller: rent, keyboardType: TextInputType.number, textDirection: TextDirection.rtl, decoration: const InputDecoration(labelText: 'قيمة الإيجار الشهري')),
        if (existing?['status'] == 'مؤجرة') const Padding(padding: EdgeInsets.only(top: 10), child: Text('الوحدة مؤجرة؛ تعديل الإيجار سيحدث قيمة الإيجار في العقد النشط أيضًا.', textAlign: TextAlign.right, style: TextStyle(color: Color(0xFFD9A45E), fontSize: 12))),
        if (error != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(error!, textAlign: TextAlign.right, style: const TextStyle(color: Color(0xFFE47777)))),
      ]),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إلغاء')),
        FilledButton(onPressed: () async {
          final n = number.text.trim();
          final r = int.tryParse(rent.text) ?? 0;
          if (n.isEmpty) { set(() => error = 'أدخل رقم الوحدة.'); return; }
          if (r < 0) { set(() => error = 'قيمة الإيجار غير صحيحة.'); return; }
          try {
            if (existing == null) {
              await db.addUnit(propertyId: widget.property.id, number: n, rent: r);
            } else {
              final msg = await db.updateUnit(unitId: existing['id'] as int, number: n, rent: r);
              if (msg != null) { set(() => error = msg); return; }
            }
            if (dialogContext.mounted) Navigator.pop(dialogContext);
            await _load();
          } catch (e) {
            set(() => error = e.toString().replaceFirst('Bad state: ', ''));
          }
        }, child: const Text('حفظ')),
      ],
    )));
  }

  Future<void> _deleteUnit(Map<String,Object?> u) async {
    final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(
      title: const Text('حذف الوحدة'),
      content: Text(u['status'] == 'مؤجرة' ? 'لا يمكن حذف الوحدة المؤجرة.' : 'هل تريد حذف الوحدة ${u['number']}؟', textAlign: TextAlign.right),
      actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')), if (u['status'] != 'مؤجرة') FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('حذف'))],
    ));
    if (ok != true) return;
    final msg = await db.deleteUnit(u['id'] as int);
    if (!mounted) return;
    if (msg != null) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
    await _load();
  }
}
