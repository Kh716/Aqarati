import 'package:flutter/material.dart';
import '../app.dart';
import '../widgets/app_card.dart';

class ContractDetailsPage extends StatefulWidget {
  final int contractId;
  const ContractDetailsPage({super.key, required this.contractId});
  @override State<ContractDetailsPage> createState() => _ContractDetailsPageState();
}

class _ContractDetailsPageState extends State<ContractDetailsPage> {
  Map<String, Object?>? contract;
  List<Map<String, Object?>> payments = [];
  bool loading = true;

  @override void initState() { super.initState(); load(); }

  Future<void> load() async {
    setState(() => loading = true);
    final c = await db.contractDetails(widget.contractId);
    final p = await db.paymentLedger();
    if (!mounted) return;
    setState(() { contract = c; payments = p.where((x) => x['contract_id'] == widget.contractId).toList(); loading = false; });
  }

  String money(Object? v) => '${v ?? 0} ر.ي';

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final c = contract;
    if (c == null) return Scaffold(appBar: AppBar(title: const Text('تفاصيل العقد')), body: const Center(child: Text('العقد غير موجود')));
    final expected = (c['expected'] as int?) ?? 0;
    final paid = (c['paid'] as int?) ?? 0;
    final remaining = (c['remaining'] as int?) ?? 0;
    final progress = expected <= 0 ? 0.0 : (paid / expected).clamp(0.0, 1.0);

    return Scaffold(
      appBar: AppBar(title: Text('العقد رقم ${c['id']}')),
      body: RefreshIndicator(onRefresh: load, child: ListView(padding: const EdgeInsets.all(16), children: [
        AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Text('${c['tenant_name'] ?? '-'}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 5),
          Text('${c['property_name'] ?? '-'} • وحدة ${c['unit_number'] ?? '-'}', textAlign: TextAlign.right, style: const TextStyle(color: Color(0xFF9DAAB7))),
          const Divider(height: 25),
          _row('حالة العقد', '${c['status'] ?? '-'}'),
          _row('الإيجار الشهري', money(c['rent'])),
          _row('التأمين', money(c['deposit'])),
          _row('البداية', '${c['start_date'] ?? '-'}'),
          _row('النهاية', '${c['end_date'] ?? '-'}'),
          _row('مدة العقد', '${c['months_due'] ?? 0} شهر'),
        ])),
        const SizedBox(height: 12),
        const Text('التحصيل', textAlign: TextAlign.right, style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: _moneyCard('المستحق', expected, const Color(0xFFD9A45E))),
          const SizedBox(width: 8), Expanded(child: _moneyCard('المقبوض', paid, const Color(0xFF7ACD9B))),
          const SizedBox(width: 8), Expanded(child: _moneyCard('المتبقي', remaining, const Color(0xFFE47777))),
        ]),
        const SizedBox(height: 12),
        AppCard(child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Row(children: [const Text('نسبة التحصيل', style: TextStyle(color: Color(0xFF9DAAB7))), const Spacer(), Text('${(progress * 100).round()}%', style: const TextStyle(fontWeight: FontWeight.w900))]),
          const SizedBox(height: 10), LinearProgressIndicator(value: progress, minHeight: 8, borderRadius: BorderRadius.circular(8)),
        ])),
        const SizedBox(height: 18),
        const Text('سجل دفعات العقد', textAlign: TextAlign.right, style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        if (payments.isEmpty) const AppCard(child: Text('لا توجد دفعات لهذا العقد.', textAlign: TextAlign.right, style: TextStyle(color: Color(0xFF9DAAB7)))),
        ...payments.map((p) => Padding(padding: const EdgeInsets.only(bottom: 8), child: AppCard(child: Row(children: [
          const Icon(Icons.payments_outlined, color: Color(0xFF7ACD9B)), const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [Text(money(p['amount']), style: const TextStyle(fontWeight: FontWeight.w900)), Text('${p['period'] ?? '-'} • ${p['method'] ?? '-'} • ${p['date'] ?? '-'}', textAlign: TextAlign.right, style: const TextStyle(fontSize: 11, color: Color(0xFF9DAAB7)))])),
        ])))),
      ])),
    );
  }

  Widget _row(String a, String b) => Padding(padding: const EdgeInsets.symmetric(vertical: 5), child: Row(children: [Expanded(child: Text(a, style: const TextStyle(color: Color(0xFF9DAAB7)))), Expanded(child: Text(b, textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.w700)))]);
  Widget _moneyCard(String title, int value, Color color) => Container(padding: const EdgeInsets.all(11), decoration: BoxDecoration(color: const Color(0xFF172738), borderRadius: BorderRadius.circular(14)), child: Column(children: [Text(title, style: TextStyle(color: color, fontSize: 11)), const SizedBox(height: 5), Text(money(value), textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900))]));
}
