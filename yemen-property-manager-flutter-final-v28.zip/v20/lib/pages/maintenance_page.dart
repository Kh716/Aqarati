import 'package:flutter/material.dart';
import '../services/database_service.dart';
import '../widgets/app_card.dart';

class MaintenancePage extends StatefulWidget {
  const MaintenancePage({super.key});
  @override State<MaintenancePage> createState() => _MaintenancePageState();
}

class _MaintenancePageState extends State<MaintenancePage> {
  final db = DatabaseService.instance;
  List<Map<String,Object?>> rows = [], properties = [], units = [];
  String filter = 'الكل';
  bool loading = true;
  static const gold = Color(0xFFD9A45E);
  static const statuses = ['جديد','قيد التنفيذ','مكتمل','ملغي'];
  static const categories = ['سباكة','كهرباء','دهانات','مصاعد','تكييف','نظافة','أخرى'];

  @override void initState() { super.initState(); _load(); }
  Future<void> _load() async {
    final loadedRows = await db.maintenanceRequests(status: filter);
    final loadedProperties = await db.properties();
    final loadedUnits = await db.units();
    if (!mounted) return;
    setState(() { rows = loadedRows; properties = loadedProperties; units = loadedUnits; loading = false; });
  }
  String money(Object? value) => '${((value as num?)?.toInt() ?? 0).toString().replaceAllMapped(RegExp(r'(?=(\d{3})+(?!\d))'), (_) => ',')} ر.ي';
  Color statusColor(String status) => status == 'مكتمل' ? Colors.greenAccent : status == 'ملغي' ? Colors.grey : status == 'قيد التنفيذ' ? Colors.orangeAccent : const Color(0xFFE47777);

  Future<void> _edit([Map<String,Object?>? row]) async {
    final formKey = GlobalKey<FormState>();
    final title = TextEditingController(text: '${row?['title'] ?? ''}');
    final description = TextEditingController(text: '${row?['description'] ?? ''}');
    final technician = TextEditingController(text: '${row?['technician'] ?? ''}');
    final cost = TextEditingController(text: '${row?['cost'] ?? 0}');
    final date = TextEditingController(text: '${row?['request_date'] ?? DateTime.now().toIso8601String().substring(0,10)}');
    int? propertyId = (row?['property_id'] as num?)?.toInt() ?? (properties.isNotEmpty ? (properties.first['id'] as num).toInt() : null);
    int? unitId = (row?['unit_id'] as num?)?.toInt();
    String category = '${row?['category'] ?? categories.first}';
    String status = '${row?['status'] ?? statuses.first}';
    if (properties.isEmpty) { _message('أضف عقارًا أولًا قبل تسجيل الصيانة.'); return; }
    final saved = await showDialog<bool>(context: context, barrierDismissible: false, builder: (dialogContext) => StatefulBuilder(builder: (context, setDialog) => AlertDialog(
      title: Text(row == null ? 'طلب صيانة جديد' : 'تعديل طلب الصيانة', textAlign: TextAlign.right),
      content: SizedBox(width: 520, child: SingleChildScrollView(child: Form(key: formKey, child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextFormField(controller: title, textAlign: TextAlign.right, decoration: const InputDecoration(labelText:'عنوان المشكلة', prefixIcon:Icon(Icons.build_outlined)), validator:(v)=>v==null||v.trim().isEmpty?'أدخل عنوان المشكلة':null),
        const SizedBox(height:10),
        DropdownButtonFormField<int>(value:propertyId, isExpanded:true, decoration:const InputDecoration(labelText:'العقار'), items:properties.map((p)=>DropdownMenuItem(value:(p['id'] as num).toInt(),child:Text('${p['name']}',textAlign:TextAlign.right,overflow:TextOverflow.ellipsis))).toList(), onChanged:(v)=>setDialog((){propertyId=v; unitId=null;})),
        const SizedBox(height:10),
        DropdownButtonFormField<int?>(value:unitId, isExpanded:true, decoration:const InputDecoration(labelText:'الوحدة (اختياري)'), items:[const DropdownMenuItem<int?>(value:null,child:Text('بدون تحديد وحدة')), ...units.where((u)=>(u['property_id'] as num?)?.toInt()==propertyId).map((u)=>DropdownMenuItem<int?>(value:(u['id'] as num).toInt(),child:Text('وحدة ${u['number']}')))], onChanged:(v)=>setDialog(()=>unitId=v)),
        const SizedBox(height:10),
        DropdownButtonFormField<String>(value:category, isExpanded:true, decoration:const InputDecoration(labelText:'نوع الصيانة'), items:categories.map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(), onChanged:(v)=>setDialog(()=>category=v??categories.last)),
        const SizedBox(height:10),
        TextFormField(controller:description, textAlign:TextAlign.right, maxLines:3, decoration:const InputDecoration(labelText:'تفاصيل المشكلة')),
        const SizedBox(height:10),
        TextFormField(controller:technician, textAlign:TextAlign.right, decoration:const InputDecoration(labelText:'اسم الفني أو جهة الصيانة')),
        const SizedBox(height:10),
        TextFormField(controller:cost, textAlign:TextAlign.right, keyboardType:TextInputType.number, decoration:const InputDecoration(labelText:'التكلفة بالريال اليمني'), validator:(v)=>int.tryParse(v??'')==null||int.parse(v!)<0?'أدخل تكلفة صحيحة':null),
        const SizedBox(height:10),
        TextFormField(controller:date, textAlign:TextAlign.right, decoration:const InputDecoration(labelText:'التاريخ (YYYY-MM-DD)'), validator:(v){final value=(v??'').trim();final parsed=DateTime.tryParse(value);return parsed!=null&&parsed.toIso8601String().substring(0,10)==value?null:'أدخل تاريخًا صحيحًا بصيغة YYYY-MM-DD';}),
        const SizedBox(height:10),
        DropdownButtonFormField<String>(value:status, isExpanded:true, decoration:const InputDecoration(labelText:'حالة الطلب'), items:statuses.map((v)=>DropdownMenuItem(value:v,child:Text(v))).toList(), onChanged:(v)=>setDialog(()=>status=v??statuses.first)),
        if(status=='مكتمل') const Padding(padding:EdgeInsets.only(top:8),child:Text('سيتم تسجيل تكلفة الصيانة ضمن المصروفات تلقائيًا مرة واحدة.',textAlign:TextAlign.right,style:TextStyle(fontSize:12,color:gold))),
      ]))),
      actions: [TextButton(onPressed:()=>Navigator.pop(dialogContext,false),child:const Text('إلغاء')), FilledButton(onPressed:() { if(formKey.currentState!.validate()) Navigator.pop(dialogContext,true); },child:const Text('حفظ'))],
    )));
    if (saved == true && mounted) {
      try {
        if (unitId != null && !units.any((u) => (u['id'] as num).toInt() == unitId && (u['property_id'] as num?)?.toInt() == propertyId)) {
          _message('الوحدة المحددة لا تتبع العقار المختار. اختر الوحدة من جديد.');
          return;
        }
        await db.saveMaintenance(id:(row?['id'] as num?)?.toInt(), propertyId:propertyId!, unitId:unitId, title:title.text, category:category, description:description.text, technician:technician.text, cost:int.parse(cost.text), requestDate:date.text, status:status);
        await _load(); _message('تم حفظ طلب الصيانة.');
      } catch(e) { _message('تعذر حفظ الطلب: $e'); }
    }
    title.dispose(); description.dispose(); technician.dispose(); cost.dispose(); date.dispose();
  }

  Future<void> _delete(Map<String,Object?> row) async {
    final yes = await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('حذف طلب الصيانة'),content:const Text('سيتم حذف الطلب ومصروف الصيانة المرتبط به إن وجد. هل تريد المتابعة؟',textAlign:TextAlign.right),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('إلغاء')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('حذف'))]));
    if (yes==true) { await db.deleteMaintenance((row['id'] as num).toInt()); await _load(); }
  }
  void _message(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(text,textAlign:TextAlign.right)));

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title:const Text('إدارة الصيانة')),
    floatingActionButton: FloatingActionButton.extended(onPressed:()=>_edit(), icon:const Icon(Icons.add), label:const Text('طلب صيانة'), backgroundColor:gold, foregroundColor:Colors.black),
    body:RefreshIndicator(onRefresh:_load, child:ListView(padding:const EdgeInsets.fromLTRB(16,12,16,90),children:[
      AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.end,children:[const Text('طلبات الصيانة',style:TextStyle(fontSize:19,fontWeight:FontWeight.w900)),const SizedBox(height:6),Text('إجمالي الطلبات: ${rows.length}  •  تكاليف الطلبات المعروضة: ${money(rows.fold<int>(0,(sum,r)=>sum+((r['cost'] as num?)?.toInt()??0)))}',textAlign:TextAlign.right,style:const TextStyle(color:Color(0xFF9DAAB7))),const SizedBox(height:12),Wrap(spacing:7,runSpacing:7,alignment:WrapAlignment.end,children:['الكل',...statuses].map((v)=>ChoiceChip(label:Text(v),selected:filter==v,onSelected:(_){setState(()=>filter=v);_load();})).toList())])),
      const SizedBox(height:12),
      if(loading) const Center(child:Padding(padding:EdgeInsets.all(30),child:CircularProgressIndicator())),
      if(!loading && rows.isEmpty) const AppCard(child:Padding(padding:EdgeInsets.all(20),child:Text('لا توجد طلبات صيانة في هذا التصنيف.',textAlign:TextAlign.center))),
      ...rows.map((r)=>Padding(padding:const EdgeInsets.only(bottom:10),child:AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.end,children:[
        Row(children:[Icon(Icons.circle,size:9,color:statusColor('${r['status']}')),const SizedBox(width:6),Text('${r['status']}',style:TextStyle(color:statusColor('${r['status']}'),fontWeight:FontWeight.bold)),const Spacer(),Expanded(flex:3,child:Text('${r['title']}',textAlign:TextAlign.right,style:const TextStyle(fontWeight:FontWeight.w900,fontSize:16)))]),
        const SizedBox(height:8),Text('${r['property_name']??'عقار غير محدد'}${r['unit_number']==null?'':' • وحدة ${r['unit_number']}'}',textAlign:TextAlign.right),const SizedBox(height:4),Text('${r['category']} • ${r['request_date']}',textAlign:TextAlign.right,style:const TextStyle(color:Color(0xFF9DAAB7),fontSize:12)),
        if('${r['description']??''}'.isNotEmpty) Padding(padding:const EdgeInsets.only(top:7),child:Text('${r['description']}',textAlign:TextAlign.right)),
        const SizedBox(height:6),Row(children:[Text(money(r['cost']),style:const TextStyle(color:gold,fontWeight:FontWeight.w900)),const Spacer(),if('${r['technician']??''}'.isNotEmpty) Flexible(child:Text('الفني: ${r['technician']}',textAlign:TextAlign.right,overflow:TextOverflow.ellipsis)),IconButton(tooltip:'تعديل',onPressed:()=>_edit(r),icon:const Icon(Icons.edit_outlined)),IconButton(tooltip:'حذف',onPressed:()=>_delete(r),icon:const Icon(Icons.delete_outline,color:Colors.redAccent))]),
      ])))),
    ])),
  );
}
