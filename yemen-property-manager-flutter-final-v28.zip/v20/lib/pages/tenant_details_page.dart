import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../app.dart';
import '../widgets/app_card.dart';

class TenantDetailsPage extends StatefulWidget {
  final Map<String, Object?> tenant;
  const TenantDetailsPage({super.key, required this.tenant});
  @override State<TenantDetailsPage> createState() => _TenantDetailsPageState();
}

class _TenantDetailsPageState extends State<TenantDetailsPage> {
  List<Map<String,Object?>> contracts=[];
  List<Map<String,Object?>> payments=[];
  bool loading=true;
  List<Map<String,Object?>> balances=[];
  bool exporting=false;
  @override void initState(){super.initState();load();}
  Future<void> load() async {
    final all=await db.contracts();
    final mine=all.where((x)=>x['tenant_id']==widget.tenant['id']).toList();
    final ps=await db.payments();
    final allBalances=await db.collectionBalances();
    final ids=mine.map((x)=>x['id']).toSet();
    if(mounted)setState((){contracts=mine;payments=ps.where((x)=>ids.contains(x['contract_id'])).toList();balances=allBalances.where((x)=>ids.contains(x['id'])).toList();loading=false;});
  }
  int get paid=>payments.fold(0,(s,r)=>s+((r['amount'] as num?)?.toInt()??0));
  int get expected=>balances.fold(0,(s,r)=>s+((r['expected'] as num?)?.toInt()??0));
  int get remaining=>balances.fold(0,(s,r)=>s+((r['remaining'] as num?)?.toInt()??0));

  Future<void> exportStatement() async {
    if(exporting) return;
    setState(()=>exporting=true);
    try {
      final regular= pw.Font.ttf(await rootBundle.load('assets/fonts/NotoKufiArabic-Regular.ttf'));
      final bold= pw.Font.ttf(await rootBundle.load('assets/fonts/NotoKufiArabic-Bold.ttf'));
      final doc=pw.Document();
      final contractRows=<List<String>>[];
      for(final c in contracts){
        final b=balances.where((x)=>x['id']==c['id']).toList();
        final row=b.isEmpty? <String, Object?>{}:b.first;
        contractRows.add(['${c['id']??''}','${c['property_name']??'—'}','${c['unit_number']??'—'}','${c['rent']??0}','${row['expected']??0}','${row['paid']??0}','${row['remaining']??0}']);
      }
      final paymentRows=payments.map((p)=>['${p['date']??''}','${p['period']??''}','${p['method']??''}','${p['amount']??0}']).toList();
      doc.addPage(pw.MultiPage(pageFormat:PdfPageFormat.a4,theme:pw.ThemeData.withFont(base:regular,bold:bold),textDirection:pw.TextDirection.rtl,build:(context)=>[
        pw.Header(level:0,child:pw.Text('كشف حساب المستأجر',style:pw.TextStyle(font: bold,fontSize:20))),
        pw.Text('اسم المستأجر: ${widget.tenant['name']??''}'),
        pw.Text('الهاتف: ${widget.tenant['phone']??'—'}    رقم الهوية: ${widget.tenant['identity']??'—'}'),
        pw.Text('تاريخ التقرير: ${DateTime.now().toIso8601String().substring(0,10)}'),
        pw.SizedBox(height:12),
        pw.Wrap(spacing:12,runSpacing:8,children:[pw.Text('إجمالي المستحق: $expected ر.ي'),pw.Text('إجمالي المدفوع: $paid ر.ي'),pw.Text('المتبقي: $remaining ر.ي')]),
        pw.SizedBox(height:12),pw.Text('العقود والوحدات',style:pw.TextStyle(font:bold,fontSize:14)),
        if(contractRows.isEmpty) pw.Text('لا توجد عقود مسجلة.') else pw.TableHelper.fromTextArray(headers:['العقد','العقار','الوحدة','الإيجار','المستحق','المدفوع','المتبقي'],data:contractRows,headerStyle:pw.TextStyle(font:bold,fontSize:8),cellStyle:const pw.TextStyle(fontSize:8),cellAlignment:pw.Alignment.center),
        pw.SizedBox(height:14),pw.Text('سجل الدفعات',style:pw.TextStyle(font:bold,fontSize:14)),
        if(paymentRows.isEmpty) pw.Text('لا توجد دفعات مسجلة.') else pw.TableHelper.fromTextArray(headers:['التاريخ','الفترة','طريقة الدفع','المبلغ'],data:paymentRows,headerStyle:pw.TextStyle(font:bold,fontSize:9),cellStyle:const pw.TextStyle(fontSize:9),cellAlignment:pw.Alignment.center),
        pw.SizedBox(height:22),pw.Text('اعتماد الإدارة: ____________________       توقيع المستأجر: ____________________'),
      ]));
      await Printing.layoutPdf(onLayout:(format)=>doc.save(),name:'tenant-statement-${widget.tenant['id']}.pdf');
    } catch(e) { if(mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('تعذر إنشاء كشف الحساب: $e'))); }
    finally { if(mounted)setState(()=>exporting=false); }
  }
  @override Widget build(BuildContext context){
    return Scaffold(appBar:AppBar(title:const Text('تفاصيل المستأجر')),body:loading?const Center(child:CircularProgressIndicator()):ListView(padding:const EdgeInsets.all(16),children:[
      AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.end,children:[Text('${widget.tenant['name']}',style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:8),Text('الهاتف: ${widget.tenant['phone']??'—'}'),Text('رقم الهوية: ${widget.tenant['identity']??'—'}'),Text('الحالة: ${widget.tenant['status']??'نشط'}')])) ,
      const SizedBox(height:14),
      Row(children:[Expanded(child:_stat('العقود',contracts.length.toString())),const SizedBox(width:8),Expanded(child:_stat('المستحق', '$expected ر.ي'))]),
      const SizedBox(height:8),Row(children:[Expanded(child:_stat('المدفوع', '$paid ر.ي')),const SizedBox(width:8),Expanded(child:_stat('المتبقي', '$remaining ر.ي'))]),
      const SizedBox(height:10),SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:exporting?null:exportStatement,icon:exporting?const SizedBox(width:18,height:18,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.picture_as_pdf_outlined),label:Text(exporting?'جارٍ تجهيز الكشف...':'طباعة / تصدير كشف الحساب PDF'))),
      const SizedBox(height:18),const Text('العقود والوحدات',textAlign:TextAlign.right,style:TextStyle(fontSize:19,fontWeight:FontWeight.w900)),const SizedBox(height:8),
      if(contracts.isEmpty) const AppCard(child:Text('لا يوجد عقد مرتبط بهذا المستأجر.',textAlign:TextAlign.right)) else ...contracts.map((c)=>Padding(padding:const EdgeInsets.only(bottom:8),child:AppCard(child:Column(crossAxisAlignment:CrossAxisAlignment.end,children:[Text('العقد #${c['id']}',style:const TextStyle(fontWeight:FontWeight.w800)),Text('الإيجار: ${c['rent']??0} ر.ي'),Text('الفترة: ${c['start_date']??''} إلى ${c['end_date']??''}'),Text('التأمين: ${c['deposit']??0} ر.ي'),Text('الحالة: ${c['status']??''}')])))),
      const SizedBox(height:18),const Text('الدفعات',textAlign:TextAlign.right,style:TextStyle(fontSize:19,fontWeight:FontWeight.w900)),const SizedBox(height:8),
      if(payments.isEmpty) const AppCard(child:Text('لا توجد دفعات لهذا المستأجر.',textAlign:TextAlign.right)) else ...payments.map((p)=>Padding(padding:const EdgeInsets.only(bottom:8),child:AppCard(child:Row(children:[const Icon(Icons.payments,color:Color(0xFF7ACD9B)),const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.end,children:[Text('${p['amount']} ر.ي',style:const TextStyle(fontWeight:FontWeight.w900)),Text('${p['period']} • ${p['method']} • ${p['date']}',style:const TextStyle(color:Color(0xFF9DAAB7),fontSize:11))]))]))))
    ]);
  }
  Widget _stat(String t,String v)=>AppCard(child:Column(children:[Text(v,style:const TextStyle(fontSize:18,fontWeight:FontWeight.w900,color:Color(0xFFD9A45E))),Text(t,style:const TextStyle(color:Color(0xFF9DAAB7)))]));
}
