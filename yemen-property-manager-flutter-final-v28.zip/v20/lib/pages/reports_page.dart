import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../app.dart';

class ReportsPage extends StatefulWidget {
  const ReportsPage({super.key});
  @override State<ReportsPage> createState() => _ReportsPageState();
}

class _ReportsPageState extends State<ReportsPage> {
  DateTime _from = DateTime(DateTime.now().year, DateTime.now().month, 1);
  DateTime _to = DateTime.now();
  int? _propertyId;
  int? _tenantId;
  List<Map<String,Object?>> _properties = [];
  Map<String,Object> _report = {};
  Map<String,Object>? _propertyReport;
  bool _loading = true;
  bool _propertyLoading = false;
  String _reportType = 'ملخص الأرباح';
  List<Map<String,Object?>> _allTenants = [];
  List<Map<String,Object?>> _allExpenses = [];
  List<Map<String,Object?>> _allRevenues = [];
  List<Map<String,Object?>> _allPayments = [];
  List<Map<String,Object?>> _allContracts = [];

  List<Map<String,Object?>> _inPeriod(List<Map<String,Object?>> rows) => rows.where((r) {
    final raw = (r['date'] ?? r['start_date'] ?? '').toString();
    if (raw.isEmpty) return true;
    final d = DateTime.tryParse(raw);
    if (d == null) return true;
    final day = DateTime(d.year,d.month,d.day);
    return !day.isBefore(DateTime(_from.year,_from.month,_from.day)) && !day.isAfter(DateTime(_to.year,_to.month,_to.day));
  }).toList();

  List<Map<String,Object?>> _forProperty(List<Map<String,Object?>> rows) => rows.where((r) => _propertyId == null || (r['property_id'] as num?)?.toInt() == _propertyId).toList();
  List<Map<String,Object?>> _forTenant(List<Map<String,Object?>> rows) => rows.where((r) => _tenantId == null || (r['tenant_id'] as num?)?.toInt() == _tenantId).toList();

  @override void initState() { super.initState(); _load(); }
  String _date(DateTime d) => d.toIso8601String().substring(0,10);
  String money(int v) => '${v.toString().replaceAllMapped(RegExp(r'(?=(\d{3})+(?!\d))'), (_) => ',')} ر.ي';
  int _num(Object? v) => (v as num?)?.toInt() ?? 0;

  Future<void> _load() async {
    if (mounted) setState(() => _loading = true);
    final props = await db.properties();
    final tenants = await db.tenants();
    final expenseRows = await db.expenses();
    final revenueRows = await db.revenues();
    final paymentRows = await db.paymentLedger();
    final contractRows = await db.contractsWithDetails();
    final report = await db.financialReport(startDate: _date(_from), endDate: _date(_to), propertyId: _propertyId);
    Map<String,Object>? detail;
    if (_propertyId != null) {
      detail = await db.propertyReport(propertyId: _propertyId!, startDate: _date(_from), endDate: _date(_to));
    }
    if (!mounted) return;
    setState(() { _properties = props; _allTenants = tenants; _allExpenses = expenseRows; _allRevenues = revenueRows; _allPayments = paymentRows; _allContracts = contractRows; _report = report; _propertyReport = detail; _loading = false; });
  }

  Future<void> _pickDate(bool from) async {
    final picked = await showDatePicker(context: context, initialDate: from ? _from : _to, firstDate: DateTime(2020), lastDate: DateTime(2100), locale: const Locale('ar'));
    if (picked == null) return;
    if (from) _from = picked; else _to = picked;
    if (_to.isBefore(_from)) _to = _from;
    await _load();
  }

  Future<void> _selectProperty(int? id) async {
    setState(() => _propertyId = id);
    await _load();
  }

  Future<void> _printSelectedProperty() async {
    if (_propertyId == null) return;
    setState(() => _propertyLoading = true);
    try {
      final data = _propertyReport ?? await db.propertyReport(propertyId: _propertyId!, startDate: _date(_from), endDate: _date(_to));
      await _printPropertyPdf(data);
    } finally {
      if (mounted) setState(() => _propertyLoading = false);
    }
  }

  Future<void> _printPropertyPdf(Map<String,Object> data) async {
    final regular = pw.Font.ttf(await rootBundle.load('assets/fonts/NotoKufiArabic-Regular.ttf'));
    final bold = pw.Font.ttf(await rootBundle.load('assets/fonts/NotoKufiArabic-Bold.ttf'));
    final theme = pw.ThemeData.withFont(base: regular, bold: bold);
    final doc = pw.Document(theme: theme);
    final property = (data['property'] as Map).cast<String,Object?>();
    final units = ((data['units'] as List?) ?? const []).cast<Map<String,Object?>>();
    final expenses = ((data['expensesList'] as List?) ?? const []).cast<Map<String,Object?>>();
    final revenues = ((data['revenuesList'] as List?) ?? const []).cast<Map<String,Object?>>();
    final title = '${property['name'] ?? 'العقار'}';
    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      textDirection: pw.TextDirection.rtl,
      build: (_) => [
        pw.Text('تقرير العقار التفصيلي', style: pw.TextStyle(font: bold, fontSize: 20)),
        pw.SizedBox(height: 6),
        pw.Text(title, style: pw.TextStyle(font: bold, fontSize: 15)),
        pw.Text('${property['city'] ?? ''} - ${property['address'] ?? ''}', style: pw.TextStyle(font: regular, fontSize: 9)),
        pw.Text('الفترة: ${_date(_from)} إلى ${_date(_to)}', style: pw.TextStyle(font: regular, fontSize: 9)),
        pw.SizedBox(height: 12),
        _pdfSummary(data, regular, bold),
        pw.SizedBox(height: 8),
        _pdfPropertyStats(data, regular, bold),
        pw.SizedBox(height: 14),
        pw.Text('الوحدات والمستأجرون والتحصيل', style: pw.TextStyle(font: bold, fontSize: 14)),
        pw.SizedBox(height: 6),
        if (units.isEmpty) pw.Text('لا توجد وحدات.', style: pw.TextStyle(font: regular, fontSize: 9))
        else pw.TableHelper.fromTextArray(
          headers: const ['الوحدة', 'المستأجر', 'الإيجار', 'المستحق', 'المدفوع', 'المتبقي'],
          data: units.map((u) => [
            '${u['number'] ?? '-'}',
            '${u['tenant_name'] ?? 'شاغرة'}',
            money(_num(u['contract_rent'] ?? u['rent'])),
            money(_num(u['expected'])),
            money(_num(u['paid'])),
            money(_num(u['remaining'])),
          ]).toList(),
          headerStyle: pw.TextStyle(font: bold, fontSize: 7),
          cellStyle: pw.TextStyle(font: regular, fontSize: 7),
          cellAlignment: pw.Alignment.center,
          headerAlignment: pw.Alignment.center,
          border: pw.TableBorder.all(color: PdfColors.grey400, width: .5),
          headerDecoration: const pw.BoxDecoration(color: PdfColors.grey300),
        ),
        pw.SizedBox(height: 16),
        pw.Text('المصروفات المسجلة على العقار', style: pw.TextStyle(font: bold, fontSize: 14)),
        pw.SizedBox(height: 6),
        if (expenses.isEmpty) pw.Text('لا توجد مصروفات خلال الفترة.', style: pw.TextStyle(font: regular, fontSize: 9))
        else pw.TableHelper.fromTextArray(
          headers: const ['التاريخ', 'البند', 'المبلغ'],
          data: expenses.map((e) => ['${e['date'] ?? '-'}', '${e['title'] ?? '-'}', money(_num(e['amount']))]).toList(),
          headerStyle: pw.TextStyle(font: bold, fontSize: 8), cellStyle: pw.TextStyle(font: regular, fontSize: 8),
          cellAlignment: pw.Alignment.center, headerAlignment: pw.Alignment.center,
          border: pw.TableBorder.all(color: PdfColors.grey400, width: .5), headerDecoration: const pw.BoxDecoration(color: PdfColors.grey300),
        ),
        pw.SizedBox(height: 16),
        pw.Text('الإيرادات الأخرى المسجلة على العقار', style: pw.TextStyle(font: bold, fontSize: 14)),
        pw.SizedBox(height: 6),
        if (revenues.isEmpty) pw.Text('لا توجد إيرادات أخرى خلال الفترة.', style: pw.TextStyle(font: regular, fontSize: 9))
        else pw.TableHelper.fromTextArray(
          headers: const ['التاريخ', 'البيان', 'المبلغ'],
          data: revenues.map((e) => ['${e['date'] ?? '-'}', '${e['title'] ?? '-'}', money(_num(e['amount']))]).toList(),
          headerStyle: pw.TextStyle(font: bold, fontSize: 8), cellStyle: pw.TextStyle(font: regular, fontSize: 8),
          cellAlignment: pw.Alignment.center, headerAlignment: pw.Alignment.center,
          border: pw.TableBorder.all(color: PdfColors.grey400, width: .5), headerDecoration: const pw.BoxDecoration(color: PdfColors.grey300),
        ),
        pw.SizedBox(height: 22),
        pw.Divider(color: PdfColors.grey500),
        pw.SizedBox(height: 8),
        pw.Row(textDirection: pw.TextDirection.rtl, mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
          pw.Text('إعداد التقرير', style: pw.TextStyle(font: regular, fontSize: 9)),
          pw.Text('اعتماد الإدارة', style: pw.TextStyle(font: regular, fontSize: 9)),
        ]),
        pw.SizedBox(height: 28),
        pw.Row(textDirection: pw.TextDirection.rtl, mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
          pw.Container(width: 150, child: pw.Divider()),
          pw.Container(width: 150, child: pw.Divider()),
        ]),
        pw.SizedBox(height: 6),
        pw.Align(alignment: pw.Alignment.center, child: pw.Text('مدير العقارات اليمني • تقرير رسمي', style: pw.TextStyle(font: regular, fontSize: 8, color: PdfColors.grey700))),
      ],
    ));
    await Printing.layoutPdf(onLayout: (_) => doc.save(), name: 'تقرير-${title.replaceAll(' ', '_')}.pdf');
  }

  pw.Widget _pdfSummary(Map<String,Object> data, pw.Font regular, pw.Font bold) => pw.Container(
    padding: const pw.EdgeInsets.all(10),
    decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey400), borderRadius: pw.BorderRadius.circular(6)),
    child: pw.Wrap(spacing: 18, runSpacing: 8, children: [
      _pdfMetric('المستحق', money(_num(data['expected'])), regular, bold),
      _pdfMetric('المدفوع', money(_num(data['paid'])), regular, bold),
      _pdfMetric('المتبقي', money(_num(data['remaining'])), regular, bold),
      _pdfMetric('المصروفات', money(_num(data['expenses'])), regular, bold),
      _pdfMetric('الإيرادات', money(_num(data['revenues'])), regular, bold),
      _pdfMetric('صافي العقار', money(_num(data['cashNet'])), regular, bold),
    ]),
  );
  pw.Widget _pdfPropertyStats(Map<String,Object> data, pw.Font regular, pw.Font bold) {
    final units = ((data['units'] as List?) ?? const []);
    final occupied = units.where((u) => (u as Map)['status'] == 'مؤجرة').length;
    final vacant = units.length - occupied;
    return pw.Container(
      padding: const pw.EdgeInsets.all(9),
      decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey400), borderRadius: pw.BorderRadius.circular(6)),
      child: pw.Row(textDirection: pw.TextDirection.rtl, mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
        _pdfMetric('إجمالي الوحدات', '${units.length}', regular, bold),
        _pdfMetric('المؤجرة', '$occupied', regular, bold),
        _pdfMetric('الشاغرة', '$vacant', regular, bold),
        _pdfMetric('المتأخرات', '${data['overdueUnits'] ?? 0}', regular, bold),
      ]),
    );
  }

  pw.Widget _pdfMetric(String label, String value, pw.Font regular, pw.Font bold) => pw.Container(width: 155, child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.end, children: [pw.Text(label, style: pw.TextStyle(font: regular, fontSize: 8)), pw.Text(value, style: pw.TextStyle(font: bold, fontSize: 11))]));

  @override Widget build(BuildContext context) {
    final r = _report;
    return Scaffold(
      appBar: AppBar(title: const Text('التقارير والإحصائيات')),
      body: RefreshIndicator(onRefresh: _load, child: ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 30), children: [
        _heroHeader(),
        const SizedBox(height: 14),
        _filters(),
        const SizedBox(height: 10),
        _reportTypeSelector(),
        const SizedBox(height: 14),
        if (_loading) const Center(child: Padding(padding: EdgeInsets.all(30), child: CircularProgressIndicator())) else ...[
          _summaryGrid(r),
          const SizedBox(height: 14),
          _selectedReportBody(),
          const SizedBox(height: 14),
        ],
      ])),
    );
  }

  Widget _heroHeader() => Container(padding: const EdgeInsets.all(18), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF172B3D), Color(0xFF10202E)]), borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white10)), child: Row(textDirection: TextDirection.rtl, children: [Container(width: 48,height:48,decoration:BoxDecoration(color:kGold.withOpacity(.16),borderRadius:BorderRadius.circular(15)),child:const Icon(Icons.analytics_rounded,color:kGold,size:27)),const SizedBox(width:12),const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.end,children:[Text('التقرير المالي والتحصيلي',textAlign:TextAlign.right,style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),SizedBox(height:3),Text('تحليل العقار والوحدات والتحصيل والمصروفات',textAlign:TextAlign.right,style:TextStyle(color:kMuted,fontSize:11))]))]));

  Widget _filters() => Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(children: [
    Row(textDirection: TextDirection.rtl, children: [Expanded(child: _dateButton('من', _from, () => _pickDate(true))), const SizedBox(width: 8), Expanded(child: _dateButton('إلى', _to, () => _pickDate(false)))]),
    const SizedBox(height: 10),
    DropdownButtonFormField<int?>(value: _propertyId, decoration: const InputDecoration(labelText:'العقار', prefixIcon:Icon(Icons.apartment_rounded), border:OutlineInputBorder()), items:[const DropdownMenuItem<int?>(value:null,child:Text('كل العقارات')), ..._properties.map((p)=>DropdownMenuItem<int?>(value:p['id'] as int,child:Text('${p['name']}')))], onChanged:_selectProperty),
    const SizedBox(height:10),
    DropdownButtonFormField<int?>(value: _tenantId, isExpanded: true, decoration: const InputDecoration(labelText:'المستأجر', prefixIcon:Icon(Icons.person_outline), border:OutlineInputBorder()), items:[const DropdownMenuItem<int?>(value:null,child:Text('كل المستأجرين')), ..._allTenants.map((t)=>DropdownMenuItem<int?>(value:t['id'] as int,child:Text('${t['name']}')))], onChanged:(id){setState(()=>_tenantId=id);_load();}),
    const SizedBox(height:10),
    Row(textDirection: TextDirection.rtl, children:[Expanded(child:FilledButton.icon(onPressed:_load,icon:const Icon(Icons.refresh),label:const Text('تحديث التقرير'))), if(_propertyId!=null) ...[const SizedBox(width:8),Expanded(child:OutlinedButton.icon(onPressed:_propertyLoading?null:_printSelectedProperty,icon:_propertyLoading?const SizedBox(width:17,height:17,child:CircularProgressIndicator(strokeWidth:2)):const Icon(Icons.print_rounded),label:const Text('طباعة العقار')))]]),
  ])));

  Widget _reportTypeSelector() => Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
    const Text('نوع التقرير التفصيلي', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
    const SizedBox(height: 8),
    DropdownButtonFormField<String>(value: _reportType, isExpanded: true, decoration: const InputDecoration(border: OutlineInputBorder(), prefixIcon: Icon(Icons.description_outlined), labelText: 'اختر التقرير'), items: const [
      DropdownMenuItem(value: 'تقرير العقار', child: Text('تقرير العقار')),
      DropdownMenuItem(value: 'تقرير المستأجر', child: Text('تقرير المستأجر')),
      DropdownMenuItem(value: 'تقرير التحصيل', child: Text('تقرير التحصيل')),
      DropdownMenuItem(value: 'تقرير المصروفات', child: Text('تقرير المصروفات')),
      DropdownMenuItem(value: 'تقرير الإيرادات والأرباح', child: Text('تقرير الإيرادات والأرباح')),
      DropdownMenuItem(value: 'تقرير العقود', child: Text('تقرير العقود')),
    ], onChanged: (v) { if (v != null) setState(() => _reportType = v); }),
  ])));

  Widget _selectedReportBody() {
    final expenses = _forProperty(_inPeriod(_allExpenses));
    final revenues = _forProperty(_inPeriod(_allRevenues));
    final payments = _forTenant(_forProperty(_inPeriod(_allPayments)));
    final contracts = _forTenant(_forProperty(_allContracts)).where((c) {
      final start = DateTime.tryParse('${c['start_date'] ?? ''}');
      final end = DateTime.tryParse('${c['end_date'] ?? ''}');
      return (start == null || !start.isAfter(_to)) && (end == null || !end.isBefore(_from));
    }).toList();
    if (_reportType == 'تقرير العقار') {
      if (_propertyId == null) return _hintCard('اختر عقارًا من عامل التصفية لعرض الوحدات والمستأجرين والتحصيل الخاص به.');
      return Column(children: [_propertyReportHeader(_propertyReport, (( _propertyReport?['units'] as List?) ?? const []).cast<Map<String,Object?>>(), (( _propertyReport?['expensesList'] as List?) ?? const []).cast<Map<String,Object?>>()), const SizedBox(height: 10), _unitSection((( _propertyReport?['units'] as List?) ?? const []).cast<Map<String,Object?>>()), _exportButton(_printSelectedProperty, 'تصدير تقرير العقار PDF')]);
    }
    if (_reportType == 'تقرير المستأجر') {
      final tenantRows = _allTenants.where((t) => t['status'] != 'محذوف' && (_tenantId == null || t['id'] == _tenantId)).map((t) => {'الاسم':t['name']??'-','الهاتف':t['phone']??'-','رقم الهوية':t['identity']??'-','الحالة':t['status']??'-'}).toList();
      final tenantContracts = _forTenant(_forProperty(contracts)).map((c)=>{'العقار':c['property_name']??'-','الوحدة':c['unit_number']??'-','الإيجار الشهري':money(_num(c['rent'])),'بداية العقد':c['start_date']??'-','نهاية العقد':c['end_date']??'-','الحالة':c['status']??'-'}).toList();
      final tenantPayments = _forTenant(_forProperty(_inPeriod(_allPayments))).map((p)=>{'تاريخ الدفعة':p['date']??'-','العقار':p['property_name']??'-','الوحدة':p['unit_number']??'-','الفترة':p['period']??'-','المبلغ':money(_num(p['amount']))}).toList();
      return Column(children:[_rowsCard('بيانات المستأجر',tenantRows,'لا يوجد مستأجرون مسجلون.'),const SizedBox(height:10),_rowsCard('عقود المستأجر ضمن الفترة',tenantContracts,'لا توجد عقود لهذا المستأجر ضمن الفترة.'),const SizedBox(height:10),_rowsCard('دفعات المستأجر ضمن الفترة',tenantPayments,'لا توجد دفعات لهذا المستأجر ضمن الفترة.')]);
    }
    if (_reportType == 'تقرير التحصيل') return _rowsCard('سجل التحصيل خلال الفترة', payments.map((p) => {'التاريخ':p['date']??'-','المستأجر':p['tenant_name']??'-','العقار':p['property_name']??'-','الوحدة':p['unit_number']??'-','طريقة الدفع':p['method']??'-','المبلغ':money(_num(p['amount']))}).toList(), 'لا توجد دفعات خلال الفترة المحددة.');
    if (_reportType == 'تقرير المصروفات') return _rowsCard('تفاصيل المصروفات', expenses.map((e) => {'التاريخ':e['date']??'-','البند':e['title']??'-','العقار':e['property']??e['property_name']??'-','المبلغ':money(_num(e['amount']))}).toList(), 'لا توجد مصروفات خلال الفترة المحددة.');
    if (_reportType == 'تقرير الإيرادات والأرباح') return Column(children: [_profitCard(revenues.fold<int>(0,(s,e)=>s+_num(e['amount'])), expenses.fold<int>(0,(s,e)=>s+_num(e['amount'])), payments.fold<int>(0,(s,e)=>s+_num(e['amount']))), const SizedBox(height:10), _rowsCard('الإيرادات الأخرى', revenues.map((e) => {'التاريخ':e['date']??'-','البيان':e['title']??'-','العقار':e['property_name']??'-','المبلغ':money(_num(e['amount']))}).toList(), 'لا توجد إيرادات أخرى خلال الفترة.')]);
    return _rowsCard('تقرير العقود', contracts.map((c) => {'المستأجر':c['tenant_name']??'-','العقار':c['property_name']??'-','الوحدة':c['unit_number']??'-','الإيجار':money(_num(c['rent'])),'بداية العقد':c['start_date']??'-','نهاية العقد':c['end_date']??'-','الحالة':c['status']??'-'}).toList(), 'لا توجد عقود ضمن الفترة المحددة.');
  }

  Widget _hintCard(String text) => Card(child: Padding(padding: const EdgeInsets.all(16), child: Text(text, textAlign: TextAlign.right, style: const TextStyle(color:kMuted))));
  Widget _exportButton(VoidCallback action, String label) => SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: action, icon: const Icon(Icons.picture_as_pdf), label: Text(label)));
  Widget _profitCard(int revenue, int expense, int collection) => Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [const Text('ملخص الإيرادات والأرباح النقدية', style: TextStyle(fontSize:17,fontWeight:FontWeight.w900)), const SizedBox(height:10), _lineMetric('الإيجارات المحصلة', collection), _lineMetric('الإيرادات الأخرى', revenue), _lineMetric('المصروفات', -expense), const Divider(), _lineMetric('صافي التدفق النقدي', collection + revenue - expense)])));
  Widget _lineMetric(String title, int amount) => Padding(padding: const EdgeInsets.symmetric(vertical:5), child: Row(textDirection:TextDirection.rtl, children:[Expanded(child:Text(title,textAlign:TextAlign.right)), Text(money(amount),style:TextStyle(fontWeight:FontWeight.w900,color:amount<0?const Color(0xFFE47777):kGold))]));
  Widget _rowsCard(String title, List<Map<String,Object?>> rows, String emptyText) => Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment:CrossAxisAlignment.end, children: [Text(title,textAlign:TextAlign.right,style:const TextStyle(fontSize:17,fontWeight:FontWeight.w900)), const SizedBox(height:8), if(rows.isEmpty) Text(emptyText,style:const TextStyle(color:kMuted)) else ...rows.map((row) => Container(width:double.infinity,margin:const EdgeInsets.only(bottom:8),padding:const EdgeInsets.all(11),decoration:BoxDecoration(color:const Color(0xFF0E1A26),borderRadius:BorderRadius.circular(12)),child:Column(crossAxisAlignment:CrossAxisAlignment.end,children:row.entries.map((e)=>Padding(padding:const EdgeInsets.symmetric(vertical:2),child:Text('${e.key}: ${e.value}',textAlign:TextAlign.right,style:TextStyle(fontSize:12,fontWeight:e.key=='المبلغ'?FontWeight.w900:FontWeight.normal,color:e.key=='المبلغ'?kGold:null))).toList()))), const SizedBox(height:8), _exportButton(_pdfSelectedReport, 'معاينة وتصدير هذا التقرير PDF')])));

  Future<void> _pdfSelectedReport() async {
    final regular = pw.Font.ttf(await rootBundle.load('assets/fonts/NotoKufiArabic-Regular.ttf'));
    final bold = pw.Font.ttf(await rootBundle.load('assets/fonts/NotoKufiArabic-Bold.ttf'));
    final doc = pw.Document(theme: pw.ThemeData.withFont(base: regular, bold: bold));
    final rows = _reportRowsForPdf();
    doc.addPage(pw.MultiPage(pageFormat:PdfPageFormat.a4,textDirection:pw.TextDirection.rtl,build: (_) => [
      pw.Text(_reportType,style:pw.TextStyle(font:bold,fontSize:20)),
      pw.Text('الفترة: ${_date(_from)} إلى ${_date(_to)}',style:pw.TextStyle(font:regular,fontSize:9)),
      pw.Text('العقار: ${_properties.firstWhere((p)=>p['id']==_propertyId,orElse:()=>{'name':'كل العقارات'})['name']??'كل العقارات'}',style:pw.TextStyle(font:regular,fontSize:9)),
      pw.SizedBox(height:12),
      if(rows.isEmpty) pw.Text('لا توجد بيانات ضمن عوامل التصفية.',style:pw.TextStyle(font:regular,fontSize:11)) else pw.TableHelper.fromTextArray(headers:rows.first.keys.toList(),data:rows.map((r)=>r.values.map((v)=>'$v').toList()).toList(),headerStyle:pw.TextStyle(font:bold,fontSize:8),cellStyle:pw.TextStyle(font:regular,fontSize:7),cellAlignment:pw.Alignment.center,headerAlignment:pw.Alignment.center,border:pw.TableBorder.all(color:PdfColors.grey400,width:.5)),
    ]));
    await Printing.layoutPdf(onLayout: (_) => doc.save(), name: '${_reportType.replaceAll(' ','_')}.pdf');
  }
  List<Map<String,Object?>> _reportRowsForPdf() {
    if (_reportType == 'تقرير المستأجر') {
      final cs = _forTenant(_forProperty(_allContracts)).where((c){final start=DateTime.tryParse('${c['start_date']??''}');final end=DateTime.tryParse('${c['end_date']??''}');return (start==null||!start.isAfter(_to))&&(end==null||!end.isBefore(_from));}).map((c)=>{'النوع':'عقد','الاسم':c['tenant_name']??'-','العقار':c['property_name']??'-','الوحدة':c['unit_number']??'-','التاريخ':'${c['start_date']??'-'} إلى ${c['end_date']??'-'}','المبلغ':money(_num(c['rent'])),'الحالة':c['status']??'-'});
      final ps = _forTenant(_forProperty(_inPeriod(_allPayments))).map((p)=>{'النوع':'دفعة','الاسم':p['tenant_name']??'-','العقار':p['property_name']??'-','الوحدة':p['unit_number']??'-','التاريخ':p['date']??'-','المبلغ':money(_num(p['amount'])),'الحالة':'مسجلة'});
      return [...cs,...ps];
    }
    if (_reportType == 'تقرير التحصيل') return _forTenant(_forProperty(_inPeriod(_allPayments))).map((p)=>{'التاريخ':p['date']??'-','المستأجر':p['tenant_name']??'-','العقار':p['property_name']??'-','الوحدة':p['unit_number']??'-','المبلغ':money(_num(p['amount']))}).toList();
    if (_reportType == 'تقرير المصروفات') return _forProperty(_inPeriod(_allExpenses)).map((e)=>{'التاريخ':e['date']??'-','البند':e['title']??'-','العقار':e['property']??e['property_name']??'-','المبلغ':money(_num(e['amount']))}).toList();
    if (_reportType == 'تقرير الإيرادات والأرباح') return _forProperty(_inPeriod(_allRevenues)).map((e)=>{'التاريخ':e['date']??'-','البيان':e['title']??'-','العقار':e['property_name']??'-','المبلغ':money(_num(e['amount']))}).toList();
    return _forTenant(_forProperty(_allContracts)).where((c){final start=DateTime.tryParse('${c['start_date']??''}');final end=DateTime.tryParse('${c['end_date']??''}');return (start==null||!start.isAfter(_to))&&(end==null||!end.isBefore(_from));}).map((c)=>{'المستأجر':c['tenant_name']??'-','العقار':c['property_name']??'-','الوحدة':c['unit_number']??'-','الإيجار':money(_num(c['rent'])),'بداية العقد':c['start_date']??'-','نهاية العقد':c['end_date']??'-','الحالة':c['status']??'-'}).toList();
  }

  Widget _summaryGrid(Map<String,Object> r) => GridView.count(crossAxisCount:2,mainAxisSpacing:10,crossAxisSpacing:10,childAspectRatio:1.75,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),children:[_summary('الإيرادات',_num(r['revenues']),Icons.trending_up),_summary('المصروفات',_num(r['expenses']),Icons.trending_down),_summary('صافي الدخل',_num(r['net']),Icons.account_balance_wallet_rounded),_summary('المستحق',_num(r['expected']),Icons.event_note),_summary('المقبوض',_num(r['paid']),Icons.payments_rounded),_summary('المتبقي',_num(r['remaining']),Icons.warning_amber_rounded)]);
  Widget _summary(String title,int value,IconData icon)=>Card(child:Padding(padding:const EdgeInsets.all(12),child:Row(textDirection:TextDirection.rtl,children:[Container(width:38,height:38,decoration:BoxDecoration(color:kGold.withOpacity(.13),borderRadius:BorderRadius.circular(12)),child:Icon(icon,color:kGold,size:21)),const SizedBox(width:9),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.end,children:[Text(title,style:const TextStyle(color:kMuted,fontSize:11)),const SizedBox(height:3),Text(money(value),textAlign:TextAlign.right,style:const TextStyle(fontSize:16,fontWeight:FontWeight.w900))]))])));

  Widget _propertyReportHeader(Map<String,Object>? detail,List<Map<String,Object?>> units,List<Map<String,Object?>> expenses){final p=(detail?['property'] as Map?)?.cast<String,Object?>()??{};final occupied=units.where((u)=>u['status']=='مؤجرة').length;return Card(child:Padding(padding:const EdgeInsets.all(15),child:Column(crossAxisAlignment:CrossAxisAlignment.end,children:[Row(textDirection:TextDirection.rtl,children:[const Icon(Icons.apartment_rounded,color:kGold),const SizedBox(width:8),Expanded(child:Text('${p['name']??'العقار'}',textAlign:TextAlign.right,style:const TextStyle(fontSize:20,fontWeight:FontWeight.w900))),Text('${units.length} وحدة',style:const TextStyle(color:kMuted,fontSize:11))]),const SizedBox(height:5),Text('${p['city']??''} • ${p['address']??''}',textAlign:TextAlign.right,style:const TextStyle(color:kMuted,fontSize:11)),const SizedBox(height:12),Wrap(textDirection: TextDirection.rtl, spacing: 7, runSpacing: 7, children: [SizedBox(width: 100, child: _mini('مؤجرة', '$occupied')), SizedBox(width: 100, child: _mini('شاغرة', '${units.length - occupied}')), SizedBox(width: 100, child: _mini('متأخرات', '${detail?['overdueUnits'] ?? 0}'))])])));}
  Widget _mini(String a,String b)=>Expanded(child:Container(padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:const Color(0xFF0E1A26),borderRadius:BorderRadius.circular(12)),child:Column(crossAxisAlignment:CrossAxisAlignment.end,children:[Text(a,style:const TextStyle(color:kMuted,fontSize:10)),const SizedBox(height:2),Text(b,style:const TextStyle(fontSize:16,fontWeight:FontWeight.w900))])));

  Widget _propertyCashNet(Map<String,Object> detail) {
    final value = _num(detail['cashNet']);
    return Card(child: Padding(padding: const EdgeInsets.all(14), child: Row(textDirection: TextDirection.rtl, children: [
      Container(width: 42, height: 42, decoration: BoxDecoration(color: kGold.withOpacity(.14), borderRadius: BorderRadius.circular(12)), child: const Icon(Icons.account_balance_wallet_rounded, color: kGold)),
      const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
        const Text('صافي العقار', style: TextStyle(color: kMuted, fontSize: 11)),
        const SizedBox(height: 2),
        Text(money(value), textAlign: TextAlign.right, style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: value >= 0 ? const Color(0xFF7ACD9B) : const Color(0xFFE47777))),
        const SizedBox(height: 2),
        const Text('المدفوع من الإيجارات + الإيرادات الأخرى − المصروفات', textAlign: TextAlign.right, style: TextStyle(color: kMuted, fontSize: 9)),
      ])),
    ])));
  }

  Widget _unitSection(List<Map<String,Object?>> units)=>Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.end,children:[const Text('الوحدات والمستأجرون والتحصيل',textAlign:TextAlign.right,style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:9),if(units.isEmpty)const Text('لا توجد وحدات',style:TextStyle(color:kMuted)) else ...units.map(_unitReportCard)])));
  Widget _unitReportCard(Map<String,Object?> u){final remaining=_num(u['remaining']);final rented=u['tenant_name']!=null && '${u['tenant_name']}'.trim().isNotEmpty;return Container(margin:const EdgeInsets.only(bottom:8),padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:const Color(0xFF0E1A26),borderRadius:BorderRadius.circular(14),border:Border.all(color:Colors.white10)),child:Column(crossAxisAlignment:CrossAxisAlignment.end,children:[Row(textDirection:TextDirection.rtl,children:[Icon(rented?Icons.person_rounded:Icons.home_work_outlined,color:rented?kGold:kMuted),const SizedBox(width:7),Expanded(child:Text('وحدة ${u['number']}',textAlign:TextAlign.right,style:const TextStyle(fontWeight:FontWeight.w900))),Text(rented?'مؤجرة':'شاغرة',style:TextStyle(color:rented?kGold:kMuted,fontSize:11))]),if(rented) ...[const SizedBox(height:5),Text('${u['tenant_name']}',textAlign:TextAlign.right,style:const TextStyle(fontWeight:FontWeight.w700)),Text('الإيجار: ${money(_num(u['contract_rent'] ?? u['rent']))}',textAlign:TextAlign.right,style:const TextStyle(color:kMuted,fontSize:11))],const Divider(color:Colors.white10),Row(textDirection:TextDirection.rtl,children:[_moneyMini('المستحق',_num(u['expected'])),_moneyMini('المدفوع',_num(u['paid'])),_moneyMini('المتبقي',remaining,color:remaining>0?const Color(0xFFE47777):const Color(0xFF7ACD9B))]) ]));}
  Widget _moneyMini(String label,int value,{Color? color})=>Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.end,children:[Text(label,style:const TextStyle(color:kMuted,fontSize:9)),Text(money(value),textAlign:TextAlign.right,style:TextStyle(fontSize:11,fontWeight:FontWeight.w800,color:color))]));

  Widget _expenseSection(List<Map<String,Object?>> expenses)=>Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.end,children:[Row(textDirection:TextDirection.rtl,children:[const Icon(Icons.receipt_long_rounded,color:kGold),const SizedBox(width:7),const Expanded(child:Text('المصروفات المسجلة على العقار',textAlign:TextAlign.right,style:TextStyle(fontSize:18,fontWeight:FontWeight.w900))),Text(money(expenses.fold<int>(0,(s,e)=>s+_num(e['amount']))),style:const TextStyle(color:kGold,fontWeight:FontWeight.w900))]),const SizedBox(height:9),if(expenses.isEmpty)const Text('لا توجد مصروفات خلال الفترة.',style:TextStyle(color:kMuted)) else ...expenses.map((e)=>ListTile(contentPadding:EdgeInsets.zero,leading:const Icon(Icons.arrow_upward_rounded,color:Color(0xFFE47777)),title:Text('${e['title']??'-'}',textAlign:TextAlign.right),subtitle:Text('${e['date']??'-'}',textAlign:TextAlign.right,style:const TextStyle(color:kMuted,fontSize:10)),trailing:Text(money(_num(e['amount'])),style:const TextStyle(color:Color(0xFFE47777),fontWeight:FontWeight.w900)))])));

  Widget _generalContracts(List<Map<String,Object?>> contracts)=>Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.end,children:[const Text('ملخص العقود',textAlign:TextAlign.right,style:TextStyle(fontSize:18,fontWeight:FontWeight.w900)),const SizedBox(height:8),if(contracts.isEmpty)const Text('لا توجد عقود خلال الفترة المحددة.',style:TextStyle(color:kMuted)) else ...contracts.map((c)=>ListTile(contentPadding:EdgeInsets.zero,title:Text('${c['tenant_name']??'بدون مستأجر'} • وحدة ${c['unit_number']??'-'}',textAlign:TextAlign.right),subtitle:Text('${c['property_name']??'-'}\nالمستحق: ${money(_num(c['expected']))} | المدفوع: ${money(_num(c['paid']))} | المتبقي: ${money(_num(c['remaining']))}',textAlign:TextAlign.right,style:const TextStyle(color:kMuted,fontSize:11))))])));

  Future<void> _pdfGeneral() async {final r=_report;final contracts=(r['contracts'] as List<Map<String,Object?>>?)??[];final regular=pw.Font.ttf(await rootBundle.load('assets/fonts/NotoKufiArabic-Regular.ttf'));final bold=pw.Font.ttf(await rootBundle.load('assets/fonts/NotoKufiArabic-Bold.ttf'));final doc=pw.Document(theme:pw.ThemeData.withFont(base:regular,bold:bold));doc.addPage(pw.MultiPage(textDirection:pw.TextDirection.rtl,build:(_)=>[pw.Text('التقرير المالي والتحصيلي',style:pw.TextStyle(font:bold,fontSize:20)),pw.Text('الفترة: ${_date(_from)} إلى ${_date(_to)}',style:pw.TextStyle(font:regular,fontSize:9)),pw.SizedBox(height:12),_pdfSummary(r,regular,bold),pw.SizedBox(height:14),pw.Text('تفصيل العقود',style:pw.TextStyle(font:bold,fontSize:14)),pw.SizedBox(height:6),pw.TableHelper.fromTextArray(headers:const ['العقار','الوحدة','المستأجر','المستحق','المدفوع','المتبقي'],data:contracts.map((c)=>['${c['property_name']??'-'}','${c['unit_number']??'-'}','${c['tenant_name']??'-'}',money(_num(c['expected'])),money(_num(c['paid'])),money(_num(c['remaining']))]).toList(),headerStyle:pw.TextStyle(font:bold,fontSize:7),cellStyle:pw.TextStyle(font:regular,fontSize:7),cellAlignment:pw.Alignment.center,headerAlignment:pw.Alignment.center)]));await Printing.layoutPdf(onLayout:(_)=>doc.save(),name:'التقرير_العام.pdf');}

  Widget _dateButton(String label,DateTime d,VoidCallback onTap)=>OutlinedButton.icon(onPressed:onTap,icon:const Icon(Icons.calendar_month),label:Text('$label: ${_date(d)}'));
}
