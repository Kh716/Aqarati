import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'pages/login_page.dart';
import 'pages/shell_page.dart';
import 'services/auth_service.dart';
import 'services/database_service.dart';

class YemenPropertyApp extends StatelessWidget {
  const YemenPropertyApp({super.key});
  @override Widget build(BuildContext context)=>MaterialApp(
    debugShowCheckedModeBanner:false,title:'مدير العقارات اليمني',locale:const Locale('ar'),supportedLocales:const [Locale('ar')],
    localizationsDelegates:const [
      GlobalMaterialLocalizations.delegate,
      GlobalWidgetsLocalizations.delegate,
      GlobalCupertinoLocalizations.delegate,
    ],
    theme:ThemeData(brightness:Brightness.dark,scaffoldBackgroundColor:const Color(0xFF0C1621),fontFamily:'Arial',colorScheme:const ColorScheme.dark(primary:Color(0xFFD9A45E),secondary:Color(0xFFE7B46D),surface:Color(0xFF172738)),useMaterial3:true),
    builder:(context,child)=>Directionality(textDirection:TextDirection.rtl,child:child??const SizedBox.shrink()),home:const AuthGate());
}

class AuthGate extends StatefulWidget{const AuthGate({super.key});@override State<AuthGate> createState()=>_AuthGateState();}
class _AuthGateState extends State<AuthGate>{Map<String,Object?>? user;bool loading=true;
 @override void initState(){super.initState();check();}
 Future<void> check()async{final u=await AuthService.instance.currentUser();if(mounted)setState(() { user=u; loading=false; });}
 @override Widget build(BuildContext context){if(loading)return const Scaffold(body:Center(child:CircularProgressIndicator()));if(user==null)return LoginPage(onLoggedIn:check);return ShellPage(user:user!,onLogout:()async{await AuthService.instance.logout();if(mounted)setState(()=>user=null);});}
}
final db=DatabaseService.instance;
