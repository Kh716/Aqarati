import 'dart:convert';
import 'package:crypto/crypto.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'database_service.dart';

class AuthService {
  AuthService._();
  static final instance = AuthService._();
  final db = DatabaseService.instance;

  String hashPassword(String password) => sha256.convert(utf8.encode(password)).toString();

  Future<Map<String,Object?>?> login(String email, String password) async {
    final user = await db.userByEmail(email);
    if (user == null || (user['active'] as int? ?? 0) != 1) return null;
    if (user['password_hash'] != hashPassword(password)) return null;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('session_user_id', user['id'] as int);
    await prefs.setString('session_user_name', '${user['name']}');
    await prefs.setString('session_user_email', '${user['email']}');
    await prefs.setString('session_user_role', '${user['role']}');
    return user;
  }

  Future<Map<String,Object?>?> currentUser() async {
    final prefs = await SharedPreferences.getInstance();
    final id = prefs.getInt('session_user_id');
    if (id == null) return null;
    final rows = await db.database.query('users', where:'id=? AND active=1', whereArgs:[id], limit:1);
    if (rows.isEmpty) { await logout(); return null; }
    return rows.first;
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('session_user_id');
    await prefs.remove('session_user_name');
    await prefs.remove('session_user_email');
    await prefs.remove('session_user_role');
  }

  bool can(String role, String permission) {
    if (role == 'مدير النظام') return true;
    const matrix = <String,Set<String>>{
      'محاسب': {'dashboard','properties_view','tenants_view','contracts_view','payments','revenues','expenses','reports','settings','maintenance'},
      'موظف تحصيل': {'dashboard','properties_view','tenants_view','contracts_view','payments','notifications'},
      'مشاهد': {'dashboard','properties_view','tenants_view','contracts_view','reports'},
    };
    return matrix[role]?.contains(permission) ?? false;
  }
}
