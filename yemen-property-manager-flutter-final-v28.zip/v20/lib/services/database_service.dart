import 'dart:io';

import 'package:path/path.dart';
import 'package:crypto/crypto.dart';
import 'dart:convert';
import 'package:sqflite/sqflite.dart';

class DatabaseService {
  DatabaseService._();
  static final instance = DatabaseService._();
  Database? _db;

  Future<void> init() async {
    if (_db != null && _db!.isOpen) return;
    final path = join(await getDatabasesPath(), 'yemen_property_manager.db');
    _db = await openDatabase(path, version: 7, onCreate: _create, onUpgrade: (db, old, next) async {
      if (old < 2) {
        await db.execute('CREATE TABLE IF NOT EXISTS units(id INTEGER PRIMARY KEY AUTOINCREMENT, property_id INTEGER, number TEXT, rent INTEGER DEFAULT 0, status TEXT DEFAULT "شاغرة")');
        await db.execute('CREATE TABLE IF NOT EXISTS tenants(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT, identity TEXT, status TEXT DEFAULT "نشط")');
        await db.execute('CREATE TABLE IF NOT EXISTS contracts(id INTEGER PRIMARY KEY AUTOINCREMENT, unit_id INTEGER, tenant_id INTEGER, rent INTEGER, status TEXT, start_date TEXT, end_date TEXT, deposit INTEGER)');
        await db.execute('CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY AUTOINCREMENT, contract_id INTEGER, amount INTEGER, period TEXT, method TEXT, date TEXT)');
        await db.execute('CREATE TABLE IF NOT EXISTS revenues(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, amount INTEGER, date TEXT)');
      }
      if (old < 3) {
        await db.execute('ALTER TABLE expenses ADD COLUMN property_id INTEGER');
        await db.execute('ALTER TABLE revenues ADD COLUMN property_id INTEGER');
        await db.execute('''UPDATE expenses SET property_id = (SELECT id FROM properties WHERE properties.name = expenses.property LIMIT 1) WHERE property IS NOT NULL''');
      }
      if (old < 4) {
        await db.execute('''CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT UNIQUE, password_hash TEXT, role TEXT, active INTEGER DEFAULT 1, created_at TEXT)''');
        final hash = sha256.convert(utf8.encode('123456')).toString();
        await db.insert('users', {'name':'مدير النظام','email':'admin@example.com','password_hash':hash,'role':'مدير النظام','active':1,'created_at':DateTime.now().toIso8601String()}, conflictAlgorithm: ConflictAlgorithm.ignore);
      }
      if (old < 5) {
        await db.execute('''CREATE TABLE IF NOT EXISTS maintenance_requests(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          property_id INTEGER NOT NULL,
          unit_id INTEGER,
          title TEXT NOT NULL,
          category TEXT NOT NULL DEFAULT 'أخرى',
          description TEXT,
          technician TEXT,
          cost INTEGER NOT NULL DEFAULT 0,
          request_date TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'جديد',
          expense_id INTEGER,
          created_at TEXT NOT NULL
        )''');
      }
      if (old < 6) {
        await db.execute('CREATE INDEX IF NOT EXISTS idx_maintenance_property ON maintenance_requests(property_id)');
        await db.execute('CREATE INDEX IF NOT EXISTS idx_maintenance_status ON maintenance_requests(status)');
        await db.execute('CREATE INDEX IF NOT EXISTS idx_payments_contract_date ON payments(contract_id, date)');
        await db.execute('CREATE INDEX IF NOT EXISTS idx_contracts_tenant_id ON contracts(tenant_id)');
        await db.execute('CREATE INDEX IF NOT EXISTS idx_expenses_property_date ON expenses(property_id, date)');
        await db.execute('CREATE INDEX IF NOT EXISTS idx_revenues_property_date ON revenues(property_id, date)');
      }
      if (old < 7) {
        // Remove the old unconditional UNIQUE(unit_id): it incorrectly prevented
        // a unit from receiving a new contract after an earlier contract ended.
        await db.execute('CREATE TABLE contracts_v7(id INTEGER PRIMARY KEY AUTOINCREMENT, unit_id INTEGER, tenant_id INTEGER, rent INTEGER, status TEXT, start_date TEXT, end_date TEXT, deposit INTEGER)');
        await db.execute('INSERT INTO contracts_v7(id,unit_id,tenant_id,rent,status,start_date,end_date,deposit) SELECT id,unit_id,tenant_id,rent,status,start_date,end_date,deposit FROM contracts');
        await db.execute('DROP TABLE contracts');
        await db.execute('ALTER TABLE contracts_v7 RENAME TO contracts');
        await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_contracts_one_current_per_unit ON contracts(unit_id) WHERE status NOT IN ('ملغي','منتهي','منتهٍ')");
        await db.execute('CREATE INDEX IF NOT EXISTS idx_contracts_tenant_id ON contracts(tenant_id)');
        await db.execute('CREATE INDEX IF NOT EXISTS idx_payments_contract_date ON payments(contract_id, date)');
        await db.execute("UPDATE units SET status = CASE WHEN EXISTS (SELECT 1 FROM contracts c WHERE c.unit_id=units.id AND c.status NOT IN ('ملغي','منتهي','منتهٍ')) THEN 'مؤجرة' ELSE CASE WHEN status='مؤجرة' THEN 'شاغرة' ELSE status END END");
      }
    });
  }

  Future<void> _create(Database db, int version) async {
    await db.execute('CREATE TABLE properties(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, city TEXT, address TEXT, units INTEGER, occupied INTEGER, overdue INTEGER)');
    await db.execute('CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, property TEXT, property_id INTEGER, amount INTEGER, date TEXT)');
    await db.execute('CREATE TABLE units(id INTEGER PRIMARY KEY AUTOINCREMENT, property_id INTEGER, number TEXT, rent INTEGER DEFAULT 0, status TEXT DEFAULT "شاغرة")');
    await db.execute('CREATE TABLE tenants(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, phone TEXT, identity TEXT, status TEXT DEFAULT "نشط")');
    await db.execute('CREATE TABLE contracts(id INTEGER PRIMARY KEY AUTOINCREMENT, unit_id INTEGER, tenant_id INTEGER, rent INTEGER, status TEXT, start_date TEXT, end_date TEXT, deposit INTEGER)');
    await db.execute('CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT, contract_id INTEGER, amount INTEGER, period TEXT, method TEXT, date TEXT)');
    await db.execute('CREATE TABLE revenues(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, amount INTEGER, property_id INTEGER, date TEXT)');
    await db.execute('CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, email TEXT UNIQUE, password_hash TEXT, role TEXT, active INTEGER DEFAULT 1, created_at TEXT)');
    await db.execute("CREATE TABLE maintenance_requests(id INTEGER PRIMARY KEY AUTOINCREMENT, property_id INTEGER NOT NULL, unit_id INTEGER, title TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'أخرى', description TEXT, technician TEXT, cost INTEGER NOT NULL DEFAULT 0, request_date TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'جديد', expense_id INTEGER, created_at TEXT NOT NULL)");
    await db.execute('CREATE INDEX IF NOT EXISTS idx_maintenance_property ON maintenance_requests(property_id)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_maintenance_status ON maintenance_requests(status)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_payments_contract_date ON payments(contract_id, date)');
    await db.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_contracts_one_current_per_unit ON contracts(unit_id) WHERE status NOT IN ('ملغي','منتهي','منتهٍ')");
    await db.execute('CREATE INDEX IF NOT EXISTS idx_contracts_tenant_id ON contracts(tenant_id)');
    final adminHash = sha256.convert(utf8.encode('123456')).toString();
    await db.insert('users', {'name':'مدير النظام','email':'admin@example.com','password_hash':adminHash,'role':'مدير النظام','active':1,'created_at':DateTime.now().toIso8601String()});
    await db.execute('CREATE INDEX IF NOT EXISTS idx_maintenance_property ON maintenance_requests(property_id)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_maintenance_status ON maintenance_requests(status)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_payments_contract_date ON payments(contract_id, date)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_contracts_tenant_id ON contracts(tenant_id)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_expenses_property_date ON expenses(property_id, date)');
    await db.execute('CREATE INDEX IF NOT EXISTS idx_revenues_property_date ON revenues(property_id, date)');
    await db.insert('properties', {'name':'برج السعادة','city':'صنعاء','address':'شارع جدة، جوار الجامعة','units':12,'occupied':7,'overdue':2});
    await db.insert('properties', {'name':'عمارة النخبة','city':'صنعاء','address':'حي الجامعة','units':8,'occupied':4,'overdue':1});
    await db.insert('properties', {'name':'عمارة عدن','city':'عدن','address':'شارع رئيسي','units':10,'occupied':8,'overdue':2});
    await db.insert('expenses', {'title':'كهرباء وماء','property':'عمارة النخبة','amount':50000,'date':'2026-10-01'});
    await db.insert('expenses', {'title':'نظافة','property':'عمارة النخبة','amount':28000,'date':'2026-09-12'});
    await db.insert('revenues', {'title':'إيجارات شهر أكتوبر','amount':630000,'property_id':1,'date':'2026-10-01'});
    for (final prop in [{'id':1,'count':12}, {'id':2,'count':8}, {'id':3,'count':10}]) {
      for (int i=0; i<(prop['count'] as int); i++) {
        await db.insert('units', {'property_id':prop['id'],'number':'${101+i}','rent':45000,'status': i < (prop['id']==1?7:prop['id']==2?4:8) ? 'مؤجرة' : 'شاغرة'});
      }
    }
    await db.insert('tenants', {'name':'أحمد محمد','phone':'777000111','identity':'123456789','status':'نشط'});
    await db.insert('tenants', {'name':'محمد علي','phone':'777000222','identity':'987654321','status':'نشط'});
  }

  Database get database => _db!;

  Future<String> databasePath() async => join(await getDatabasesPath(), 'yemen_property_manager.db');

  Future<String> createBackupFile() async {
    final sourcePath = await databasePath();
    await init();
    // Flush SQLite WAL changes before copying the database file.
    await _db!.rawQuery('PRAGMA wal_checkpoint(FULL)');
    await _db!.close();
    _db = null;
    try {
      final source = File(sourcePath);
      if (!await source.exists()) throw StateError('ملف قاعدة البيانات غير موجود.');
      final stamp = DateTime.now().toIso8601String().replaceAll(':', '-').replaceAll('.', '-');
      final backupPath = join(await getDatabasesPath(), 'yemen_property_manager_backup_$stamp.db');
      await source.copy(backupPath);
      final backup = File(backupPath);
      if (!await backup.exists() || await backup.length() < 1024) {
        throw StateError('لم يتم إنشاء ملف نسخة احتياطية صالح.');
      }
      return backupPath;
    } finally {
      await init();
    }
  }

  Future<void> restoreBackupFile(String backupPath) async {
    final source = File(backupPath);
    if (!await source.exists() || await source.length() < 1024) {
      throw StateError('ملف النسخة الاحتياطية غير موجود أو حجمه غير صالح.');
    }
    // Validate the selected file before touching the current database.
    Database? candidate;
    try {
      candidate = await openDatabase(backupPath, readOnly: true);
      final integrity = await candidate.rawQuery('PRAGMA integrity_check');
      if (integrity.isEmpty || integrity.first.values.first != 'ok') {
        throw StateError('قاعدة البيانات داخل النسخة الاحتياطية تالفة.');
      }
      final tables = await candidate.rawQuery("SELECT name FROM sqlite_master WHERE type='table'");
      final names = tables.map((r) => '${r['name']}').toSet();
      if (!names.containsAll(['properties', 'units', 'tenants', 'contracts', 'payments', 'expenses'])) {
        throw StateError('الملف المحدد ليس نسخة احتياطية متوافقة مع التطبيق.');
      }
      for (final table in ['properties', 'units', 'tenants', 'contracts', 'payments', 'expenses']) {
        final columns = await candidate.rawQuery('PRAGMA table_info($table)');
        if (columns.isEmpty || !columns.any((c) => c['name'] == 'id')) {
          throw StateError('جدول $table غير مكتمل في النسخة الاحتياطية.');
        }
      }
      await candidate.close();
      candidate = null;
    } catch (e) {
      if (candidate != null) await candidate.close();
      rethrow;
    }

    final targetPath = await databasePath();
    await init();
    await _db!.rawQuery('PRAGMA wal_checkpoint(FULL)');
    await _db!.close();
    _db = null;
    final target = File(targetPath);
    final safetyPath = '$targetPath.before_restore';
    var savedCurrent = false;
    try {
      if (await target.exists()) {
        await target.copy(safetyPath);
        savedCurrent = true;
      }
      await source.copy(targetPath);
      await init(); // Runs migrations for older valid backups.
      final restoredCheck = await _db!.rawQuery('PRAGMA integrity_check');
      if (restoredCheck.isEmpty || restoredCheck.first.values.first != 'ok') {
        throw StateError('فشل التحقق من سلامة قاعدة البيانات بعد الاستعادة.');
      }
      if (savedCurrent) await File(safetyPath).delete();
    } catch (e) {
      if (savedCurrent && await File(safetyPath).exists()) {
        if (_db != null && _db!.isOpen) await _db!.close();
        _db = null;
        await File(safetyPath).copy(targetPath);
        await init();
      } else {
        await init();
      }
      rethrow;
    }
  }

  Future<void> close() async {
    if (_db != null && _db!.isOpen) await _db!.close();
    _db = null;
  }

  Future<List<Map<String,Object?>>> maintenanceRequests({String? status}) async {
    final where = status == null || status == 'الكل' ? null : 'm.status = ?';
    return database.rawQuery('''SELECT m.*, p.name AS property_name, u.number AS unit_number
      FROM maintenance_requests m LEFT JOIN properties p ON p.id=m.property_id
      LEFT JOIN units u ON u.id=m.unit_id ${where == null ? '' : 'WHERE $where'}
      ORDER BY CASE m.status WHEN 'جديد' THEN 0 WHEN 'قيد التنفيذ' THEN 1 ELSE 2 END, m.id DESC''', where == null ? null : [status]);
  }

  Future<int> saveMaintenance({int? id, required int propertyId, int? unitId, required String title, required String category, required String description, required String technician, required int cost, required String requestDate, required String status}) async {
    if (title.trim().isEmpty) throw ArgumentError('عنوان الصيانة مطلوب.');
    if (cost < 0) throw ArgumentError('تكلفة الصيانة لا يمكن أن تكون سالبة.');
    final parsedDate = DateTime.tryParse(requestDate);
    if (parsedDate == null || parsedDate.toIso8601String().substring(0, 10) != requestDate) {
      throw ArgumentError('تاريخ الصيانة غير صحيح؛ استخدم YYYY-MM-DD.');
    }
    if (!['جديد', 'قيد التنفيذ', 'مكتمل', 'ملغي'].contains(status)) throw ArgumentError('حالة الصيانة غير معروفة.');
    return database.transaction((txn) async {
      final propertyRows = await txn.query('properties', columns: ['id'], where: 'id=?', whereArgs: [propertyId], limit: 1);
      if (propertyRows.isEmpty) throw StateError('العقار المحدد غير موجود.');
      if (unitId != null) {
        final unitRows = await txn.query('units', columns: ['id'], where: 'id=? AND property_id=?', whereArgs: [unitId, propertyId], limit: 1);
        if (unitRows.isEmpty) throw StateError('الوحدة المحددة لا تتبع العقار المختار.');
      }
      final values = <String, Object?>{'property_id':propertyId, 'unit_id':unitId, 'title':title.trim(), 'category':category, 'description':description.trim(), 'technician':technician.trim(), 'cost':cost, 'request_date':requestDate, 'status':status, 'created_at':DateTime.now().toIso8601String()};
      Map<String,Object?>? previous;
      if (id != null) {
        final rows = await txn.query('maintenance_requests', where:'id=?', whereArgs:[id], limit:1);
        if (rows.isEmpty) throw StateError('طلب الصيانة المراد تعديله غير موجود.');
        previous = rows.first;
      }
      var expenseId = previous?['expense_id'] as int?;
      if (expenseId != null) {
        final linkedExpense = await txn.query('expenses', columns:['id'], where:'id=?', whereArgs:[expenseId], limit:1);
        if (linkedExpense.isEmpty) expenseId = null;
      }
      if (status == 'مكتمل' && cost > 0) {
        final property = await txn.query('properties', columns:['name'], where:'id=?', whereArgs:[propertyId], limit:1);
        final propertyName = property.isEmpty ? '' : '${property.first['name']}';
        if (expenseId == null) {
          final created = await txn.insert('expenses', {'title':'صيانة: ${title.trim()}', 'property':propertyName, 'property_id':propertyId, 'amount':cost, 'date':requestDate});
          values['expense_id'] = created;
        } else {
          await txn.update('expenses', {'title':'صيانة: ${title.trim()}', 'property':propertyName, 'property_id':propertyId, 'amount':cost, 'date':requestDate}, where:'id=?', whereArgs:[expenseId]);
          values['expense_id'] = expenseId;
        }
      } else if (expenseId != null) {
        await txn.delete('expenses', where:'id=?', whereArgs:[expenseId]);
        values['expense_id'] = null;
      }
      if (id == null) return txn.insert('maintenance_requests', values);
      await txn.update('maintenance_requests', values, where:'id=?', whereArgs:[id]);
      return id;
    });
  }

  Future<void> deleteMaintenance(int id) async {
    await database.transaction((txn) async {
      final rows = await txn.query('maintenance_requests', columns:['expense_id'], where:'id=?', whereArgs:[id], limit:1);
      if (rows.isEmpty) return;
      final expenseId = rows.first['expense_id'] as int?;
      if (expenseId != null) await txn.delete('expenses', where:'id=?', whereArgs:[expenseId]);
      await txn.delete('maintenance_requests', where:'id=?', whereArgs:[id]);
    });
  }

  Future<List<Map<String,Object?>>> users() => database.query('users', orderBy:'id DESC');
  Future<Map<String,Object?>?> userByEmail(String email) async {
    final rows = await database.query('users', where:'LOWER(email)=LOWER(?)', whereArgs:[email.trim()], limit:1);
    return rows.isEmpty ? null : rows.first;
  }
  Future<int> addUser({required String name, required String email, required String passwordHash, required String role}) async => database.insert('users', {'name':name.trim(),'email':email.trim(),'password_hash':passwordHash,'role':role,'active':1,'created_at':DateTime.now().toIso8601String()});
  Future<void> updateUser({required int id, required String name, required String email, required String role, required bool active, String? passwordHash}) async {
    final values=<String,Object?>{'name':name.trim(),'email':email.trim(),'role':role,'active':active?1:0};
    if(passwordHash!=null) values['password_hash']=passwordHash;
    await database.update('users', values, where:'id=?', whereArgs:[id]);
  }
  Future<void> deleteUser(int id) async => database.delete('users', where:'id=?', whereArgs:[id]);

  Future<List<Map<String,Object?>>> properties() => database.query('properties', orderBy:'id DESC');
  Future<List<Map<String,Object?>>> expenses() => database.query('expenses', orderBy:'id DESC');
  Future<List<Map<String,Object?>>> tenants() => database.query('tenants', orderBy:'id DESC');
  Future<List<Map<String,Object?>>> contracts() => database.query('contracts', orderBy:'id DESC');
  Future<List<Map<String,Object?>>> payments() => database.query('payments', orderBy:'id DESC');
  Future<List<Map<String,Object?>>> revenues() => database.rawQuery('''
    SELECT r.*, p.name AS property_name
    FROM revenues r LEFT JOIN properties p ON p.id = r.property_id
    ORDER BY r.id DESC
  ''');
  Future<List<Map<String,Object?>>> units() => database.query('units', orderBy:'id DESC');

  Future<List<Map<String, Object?>>> contractsWithDetails() async => database.rawQuery('''
    SELECT c.*, u.number AS unit_number, u.property_id, p.name AS property_name,
           t.name AS tenant_name, t.phone AS tenant_phone, t.identity AS tenant_identity
    FROM contracts c
    LEFT JOIN units u ON u.id = c.unit_id
    LEFT JOIN properties p ON p.id = u.property_id
    LEFT JOIN tenants t ON t.id = c.tenant_id
    ORDER BY c.id DESC
  ''');

  Future<Map<String, Object?>?> contractDetails(int contractId) async {
    final rows = await collectionBalances();
    final found = rows.where((r) => r['id'] == contractId).toList();
    return found.isEmpty ? null : found.first;
  }

  Future<int> createContract(Map<String, Object?> values) async => saveContract(values);

  Future<int> saveContract(Map<String, Object?> values, {int? contractId}) async {
    final unitId = values['unit_id'] as int?;
    final tenantId = values['tenant_id'] as int?;
    final rent = values['rent'] as int? ?? 0;
    final deposit = values['deposit'] as int? ?? 0;
    final start = DateTime.tryParse('${values['start_date'] ?? ''}');
    final end = DateTime.tryParse('${values['end_date'] ?? ''}');
    final status = '${values['status'] ?? 'نشط'}';
    if (unitId == null || tenantId == null) throw StateError('اختر الوحدة والمستأجر.');
    if (rent <= 0 || deposit < 0) throw StateError('تحقق من قيمة الإيجار والتأمين.');
    if (start == null || end == null || end.isBefore(start)) throw StateError('تواريخ العقد غير صحيحة.');
    if (!['نشط','منتهي','ملغى'].contains(status)) throw StateError('حالة العقد غير صحيحة.');
    return database.transaction((txn) async {
      final unitRows = await txn.query('units', where: 'id = ?', whereArgs: [unitId], limit: 1);
      if (unitRows.isEmpty) throw StateError('الوحدة المحددة غير موجودة.');
      final tenantRows = await txn.query('tenants', where: 'id = ?', whereArgs: [tenantId], limit: 1);
      if (tenantRows.isEmpty) throw StateError('المستأجر المحدد غير موجود.');
      if (unitRows.first['status'] == 'تحت الصيانة' && status == 'نشط') throw StateError('لا يمكن تأجير وحدة تحت الصيانة.');
      if (status == 'نشط') {
        final conflicts = await txn.query('contracts', columns: ['id'], where: "unit_id = ? AND status NOT IN ('ملغي','منتهي','منتهٍ') AND (? IS NULL OR id != ?)", whereArgs: [unitId, contractId, contractId], limit: 1);
        if (conflicts.isNotEmpty) throw StateError('هذه الوحدة مرتبطة بعقد نشط بالفعل.');
      }
      int id;
      int? oldPropertyId;
      if (contractId == null) {
        id = await txn.insert('contracts', values);
      } else {
        final oldRows = await txn.query('contracts', where: 'id = ?', whereArgs: [contractId], limit: 1);
        if (oldRows.isEmpty) throw StateError('العقد المراد تعديله غير موجود.');
        id = contractId;
        await txn.update('contracts', values, where: 'id = ?', whereArgs: [id]);
        final oldUnitId = oldRows.first['unit_id'] as int?;
        if (oldUnitId != null && oldUnitId != unitId) {
          final oldUnitRows = await txn.query('units', columns: ['property_id'], where: 'id = ?', whereArgs: [oldUnitId], limit: 1);
          if (oldUnitRows.isNotEmpty) oldPropertyId = oldUnitRows.first['property_id'] as int?;
          final oldActive = await txn.query('contracts', columns: ['id'], where: "unit_id = ? AND status NOT IN ('ملغي','منتهي','منتهٍ')", whereArgs: [oldUnitId], limit: 1);
          if (oldActive.isEmpty) await txn.update('units', {'status':'شاغرة'}, where:'id = ?', whereArgs:[oldUnitId]);
        }
      }
      final unitStatus = status == 'نشط' ? 'مؤجرة' : (unitRows.first['status'] == 'تحت الصيانة' ? 'تحت الصيانة' : 'شاغرة');
      await txn.update('units', {'status': unitStatus}, where: 'id = ?', whereArgs: [unitId]);
      final propId = unitRows.first['property_id'] as int?;
      for (final pid in <int>{if (propId != null) propId, if (oldPropertyId != null) oldPropertyId}) {
        final stats = await txn.rawQuery("SELECT COUNT(*) total, SUM(CASE WHEN status = 'مؤجرة' THEN 1 ELSE 0 END) occupied FROM units WHERE property_id = ?", [pid]);
        await txn.update('properties', {'units': (stats.first['total'] as num?)?.toInt() ?? 0, 'occupied': (stats.first['occupied'] as num?)?.toInt() ?? 0}, where: 'id = ?', whereArgs: [pid]);
      }
      return id;
    });
  }

  Future<void> deleteContract(int contractId) async {
    await database.transaction((txn) async {
      final c = await txn.query('contracts', columns: ['unit_id'], where: 'id = ?', whereArgs: [contractId], limit: 1);
      if (c.isEmpty) return;
      final unitId = c.first['unit_id'] as int;
      await txn.delete('payments', where: 'contract_id = ?', whereArgs: [contractId]);
      await txn.delete('contracts', where: 'id = ?', whereArgs: [contractId]);
      await txn.update('units', {'status': 'شاغرة'}, where: 'id = ?', whereArgs: [unitId]);
      final prop = await txn.query('units', columns: ['property_id'], where: 'id = ?', whereArgs: [unitId], limit: 1);
      if (prop.isNotEmpty) {
        final pid = prop.first['property_id'] as int;
        final stats = await txn.rawQuery("SELECT COUNT(*) total, SUM(CASE WHEN status = 'مؤجرة' THEN 1 ELSE 0 END) occupied FROM units WHERE property_id = ?", [pid]);
        await txn.update('properties', {'units': (stats.first['total'] as num?)?.toInt() ?? 0, 'occupied': (stats.first['occupied'] as num?)?.toInt() ?? 0}, where: 'id = ?', whereArgs: [pid]);
      }
    });
  }

  Future<int> addProperty({required String name,required String city,required String address,int units=0}) async {
    final id=await database.insert('properties', {'name':name,'city':city,'address':address,'units':units,'occupied':0,'overdue':0});
    for(int i=0;i<units;i++){await database.insert('units', {'property_id':id,'number':'${101+i}','rent':0,'status':'شاغرة'});}
    return id;
  }
  Future<int> addExpense({required String title, required int propertyId, required int amount}) async {
    final prop = await database.query('properties', columns:['name'], where:'id = ?', whereArgs:[propertyId], limit:1);
    final propertyName = prop.isEmpty ? '' : '${prop.first['name']}';
    return database.insert('expenses', {'title':title.trim(),'property':propertyName,'property_id':propertyId,'amount':amount,'date':DateTime.now().toIso8601String().substring(0,10)});
  }

  Future<int> addRevenue({required String title, required int propertyId, required int amount}) async {
    final prop = await database.query('properties', columns:['name'], where:'id = ?', whereArgs:[propertyId], limit:1);
    final propertyName = prop.isEmpty ? '' : '${prop.first['name']}';
    return database.insert('revenues', {'title':title.trim(),'amount':amount,'property_id':propertyId,'date':DateTime.now().toIso8601String().substring(0,10)});
  }
  Future<int> addTenant({required String name,required String phone,required String identity}) => database.insert('tenants', {'name':name.trim(),'phone':phone.trim(),'identity':identity.trim(),'status':'نشط'});

  Future<void> updateTenant({required int id, required String name, required String phone, required String identity, required String status}) async {
    await database.update('tenants', {'name':name.trim(),'phone':phone.trim(),'identity':identity.trim(),'status':status}, where:'id = ?', whereArgs:[id]);
  }

  Future<Map<String,Object?>> tenantSummary(int tenantId) async {
    final contracts = await database.rawQuery("SELECT COUNT(*) c FROM contracts WHERE tenant_id = ? AND status != 'ملغي'", [tenantId]);
    final payments = await database.rawQuery('''
      SELECT COALESCE(SUM(p.amount),0) total
      FROM payments p JOIN contracts c ON c.id = p.contract_id
      WHERE c.tenant_id = ?
    ''', [tenantId]);
    final balances = await collectionBalances();
    var remaining = 0;
    var overdue = 0;
    for (final r in balances) {
      if (r['tenant_id'] == tenantId) {
        remaining += (r['remaining'] as int?) ?? 0;
        if (r['is_overdue'] == true) overdue++;
      }
    }
    return {
      'contracts': (contracts.first['c'] as num?)?.toInt() ?? 0,
      'paid': (payments.first['total'] as num?)?.toInt() ?? 0,
      'remaining': remaining,
      'overdueContracts': overdue,
    };
  }

  Future<bool> tenantHasContracts(int tenantId) async {
    final r = await database.rawQuery("SELECT COUNT(*) c FROM contracts WHERE tenant_id = ? AND status != 'ملغي'", [tenantId]);
    return ((r.first['c'] as num?)?.toInt() ?? 0) > 0;
  }

  Future<String?> deleteTenant(int tenantId) async {
    if (await tenantHasContracts(tenantId)) {
      return 'لا يمكن حذف المستأجر لأنه مرتبط بعقد قائم. قم بإلغاء العقد أولًا.';
    }
    await database.delete('tenants', where:'id = ?', whereArgs:[tenantId]);
    return null;
  }
  Future<void> delete(String table,int id) async => database.delete(table,where:'id = ?',whereArgs:[id]);

  Future<List<Map<String,Object?>>> propertyUnits(int propertyId) async => database.rawQuery('''
    SELECT u.*, c.id AS contract_id, c.rent AS contract_rent, c.status AS contract_status,
           c.start_date, c.end_date, t.name AS tenant_name, t.phone AS tenant_phone
    FROM units u LEFT JOIN contracts c ON c.unit_id = u.id
    LEFT JOIN tenants t ON t.id = c.tenant_id
    WHERE u.property_id = ? ORDER BY u.id
  ''', [propertyId]);

  Future<void> deleteProperty(int propertyId) async {
    await database.transaction((txn) async {
      final units = await txn.query('units', columns: ['id'], where: 'property_id = ?', whereArgs: [propertyId]);
      for (final unit in units) {
        await txn.delete('payments', where: 'contract_id IN (SELECT id FROM contracts WHERE unit_id = ?)', whereArgs: [unit['id']]);
        await txn.delete('contracts', where: 'unit_id = ?', whereArgs: [unit['id']]);
      }
      await txn.delete('units', where: 'property_id = ?', whereArgs: [propertyId]);
      await txn.delete('properties', where: 'id = ?', whereArgs: [propertyId]);
    });
  }

  Future<void> syncPropertyUnits({required int propertyId, required int desiredCount}) async {
    await database.transaction((txn) async {
      final rows = await txn.query('units', where: 'property_id = ?', whereArgs: [propertyId], orderBy: 'id ASC');
      if (desiredCount < rows.length) {
        final removable = rows.reversed.where((r) => r['status'] == 'شاغرة').take(rows.length - desiredCount);
        for (final row in removable) { await txn.delete('units', where: 'id = ?', whereArgs: [row['id']]); }
      } else if (desiredCount > rows.length) {
        for (int i = rows.length; i < desiredCount; i++) {
          await txn.insert('units', {'property_id': propertyId, 'number': '${101+i}', 'rent': 0, 'status': 'شاغرة'});
        }
      }
      final stats = await txn.rawQuery("SELECT COUNT(*) total, SUM(CASE WHEN status = 'مؤجرة' THEN 1 ELSE 0 END) occupied FROM units WHERE property_id = ?", [propertyId]);
      await txn.update('properties', {'units': (stats.first['total'] as num?)?.toInt() ?? 0, 'occupied': (stats.first['occupied'] as num?)?.toInt() ?? 0}, where: 'id = ?', whereArgs: [propertyId]);
    });
  }
  Future<void> update(String table,int id,Map<String,Object?> values) async => database.update(table,values,where:'id = ?',whereArgs:[id]);
  Future<int> addUnit({required int propertyId, required String number, required int rent}) async {
    final exists = await database.query('units', columns: ['id'], where: 'property_id = ? AND number = ?', whereArgs: [propertyId, number.trim()], limit: 1);
    if (exists.isNotEmpty) throw StateError('رقم الوحدة موجود مسبقًا في هذه العمارة.');
    final id = await database.insert('units', {
      'property_id': propertyId,
      'number': number.trim(),
      'rent': rent,
      'status': 'شاغرة',
    });
    await _refreshPropertyStats(propertyId);
    return id;
  }

  Future<String?> updateUnit({required int unitId, required String number, required int rent}) async {
    final unit = await database.query('units', columns: ['property_id', 'status'], where: 'id = ?', whereArgs: [unitId], limit: 1);
    if (unit.isEmpty) return 'الوحدة غير موجودة.';
    final propertyId = unit.first['property_id'] as int;
    final duplicate = await database.query('units', columns: ['id'], where: 'property_id = ? AND number = ? AND id != ?', whereArgs: [propertyId, number.trim(), unitId], limit: 1);
    if (duplicate.isNotEmpty) return 'رقم الوحدة موجود مسبقًا في هذه العمارة.';
    await database.transaction((txn) async {
      await txn.update('units', {'number': number.trim(), 'rent': rent}, where: 'id = ?', whereArgs: [unitId]);
      final contract = await txn.query('contracts', columns: ['id'], where: 'unit_id = ? AND status = ?', whereArgs: [unitId, 'نشط'], limit: 1);
      if (contract.isNotEmpty) {
        await txn.update('contracts', {'rent': rent}, where: 'id = ?', whereArgs: [contract.first['id']]);
      }
    });
    await _refreshPropertyStats(propertyId);
    return null;
  }

  Future<String?> deleteUnit(int unitId) async {
    final unit = await database.query('units', columns: ['property_id', 'status'], where: 'id = ?', whereArgs: [unitId], limit: 1);
    if (unit.isEmpty) return 'الوحدة غير موجودة.';
    if (unit.first['status'] == 'مؤجرة') return 'لا يمكن حذف وحدة مؤجرة. احذف/ألغِ العقد أولًا.';
    final propertyId = unit.first['property_id'] as int;
    await database.delete('units', where: 'id = ?', whereArgs: [unitId]);
    await _refreshPropertyStats(propertyId);
    return null;
  }

  Future<void> _refreshPropertyStats(int propertyId) async {
    final stats = await database.rawQuery("SELECT COUNT(*) total, SUM(CASE WHEN status = 'مؤجرة' THEN 1 ELSE 0 END) occupied FROM units WHERE property_id = ?", [propertyId]);
    await database.update('properties', {
      'units': (stats.first['total'] as num?)?.toInt() ?? 0,
      'occupied': (stats.first['occupied'] as num?)?.toInt() ?? 0,
    }, where: 'id = ?', whereArgs: [propertyId]);
  }


  // Monthly installments are due on the contract's start day, not simply
  // once for every calendar month touched by a date range.
  DateTime _monthlyDueDate(DateTime start, int year, int month) {
    final firstOfNextMonth = month == 12 ? DateTime(year + 1, 1, 1) : DateTime(year, month + 1, 1);
    final lastDay = firstOfNextMonth.subtract(const Duration(days: 1)).day;
    return DateTime(year, month, start.day > lastDay ? lastDay : start.day);
  }

  int _installmentsInRange(DateTime contractStart, DateTime contractEnd, DateTime rangeStart, DateTime rangeEnd) {
    if (contractEnd.isBefore(contractStart) || rangeEnd.isBefore(rangeStart)) return 0;
    final first = contractStart.isAfter(rangeStart) ? contractStart : rangeStart;
    final last = contractEnd.isBefore(rangeEnd) ? contractEnd : rangeEnd;
    if (last.isBefore(first)) return 0;
    var count = 0;
    var year = contractStart.year;
    var month = contractStart.month;
    while (year < last.year || (year == last.year && month <= last.month)) {
      final due = _monthlyDueDate(contractStart, year, month);
      if (!due.isBefore(contractStart) && !due.isBefore(first) && !due.isAfter(last)) count++;
      if (month == 12) { year++; month = 1; } else { month++; }
    }
    return count;
  }

  int _monthsDue(String startDate, String endDate) {
    final start = DateTime.tryParse(startDate);
    final contractEnd = DateTime.tryParse(endDate);
    if (start == null) return 0;
    final now = DateTime.now();
    final until = contractEnd == null || contractEnd.isAfter(now) ? now : contractEnd;
    return _installmentsInRange(start, until, start, until);
  }

  Future<List<Map<String, Object?>>> collectionBalances() async {
    final contractRows = await database.rawQuery("""
      SELECT c.*, u.number AS unit_number, u.property_id,
             p.name AS property_name, t.name AS tenant_name, t.phone AS tenant_phone
      FROM contracts c
      JOIN units u ON u.id = c.unit_id
      LEFT JOIN properties p ON p.id = u.property_id
      LEFT JOIN tenants t ON t.id = c.tenant_id
      WHERE c.status != 'ملغي'
      ORDER BY c.id DESC
    """);
    final result = <Map<String, Object?>>[];
    for (final c in contractRows) {
      final contractId = c['id'] as int;
      final rent = (c['rent'] as num?)?.toInt() ?? 0;
      final months = _monthsDue(c['start_date']?.toString() ?? '', c['end_date']?.toString() ?? '');
      final expected = rent * months;
      final paidRow = await database.rawQuery('SELECT COALESCE(SUM(amount),0) total FROM payments WHERE contract_id = ?', [contractId]);
      final paid = (paidRow.first['total'] as num?)?.toInt() ?? 0;
      final remaining = expected - paid;
      result.add({...c, 'months_due': months, 'expected': expected, 'paid': paid, 'remaining': remaining > 0 ? remaining : 0, 'overpaid': paid > expected ? paid - expected : 0, 'is_overdue': remaining > 0});
    }
    return result;
  }

  Future<Map<String, int>> contractBalance(int contractId) async {
    final rows = await collectionBalances();
    final r = rows.where((x) => x['id'] == contractId).toList();
    if (r.isEmpty) return {'expected': 0, 'paid': 0, 'remaining': 0, 'overpaid': 0};
    return {
      'expected': (r.first['expected'] as int?) ?? 0,
      'paid': (r.first['paid'] as int?) ?? 0,
      'remaining': (r.first['remaining'] as int?) ?? 0,
      'overpaid': (r.first['overpaid'] as int?) ?? 0,
    };
  }

  Future<List<Map<String, Object?>>> paymentLedger() async => database.rawQuery('''
    SELECT pay.*, c.rent AS contract_rent, c.tenant_id,
           u.number AS unit_number, p.name AS property_name,
           t.name AS tenant_name
    FROM payments pay
    LEFT JOIN contracts c ON c.id = pay.contract_id
    LEFT JOIN units u ON u.id = c.unit_id
    LEFT JOIN properties p ON p.id = u.property_id
    LEFT JOIN tenants t ON t.id = c.tenant_id
    ORDER BY pay.id DESC
  ''');

  Future<String?> addPayment({required int contractId, required int amount, required String period, required String method}) async {
    if (amount <= 0) return 'يجب أن يكون مبلغ الدفعة أكبر من صفر.';
    final balance = await contractBalance(contractId);
    final remaining = balance['remaining'] ?? 0;
    if (remaining <= 0) return 'لا يوجد مبلغ مستحق على هذا العقد حاليًا.';
    if (amount > remaining) return 'المبلغ يتجاوز المتبقي (${remaining} ر.ي).';
    await database.insert('payments', {
      'contract_id': contractId,
      'amount': amount,
      'period': period,
      'method': method,
      'date': DateTime.now().toIso8601String().substring(0,10),
    });
    return null;
  }

  Future<void> deletePayment(int paymentId) async => database.delete('payments', where:'id = ?', whereArgs:[paymentId]);

  Future<Map<String, int>> collectionSummary() async {
    final rows = await collectionBalances();
    var expected = 0, paid = 0, remaining = 0, overdueContracts = 0;
    for (final r in rows) {
      expected += (r['expected'] as int?) ?? 0;
      paid += (r['paid'] as int?) ?? 0;
      remaining += (r['remaining'] as int?) ?? 0;
      if (r['is_overdue'] == true) overdueContracts++;
    }
    return {'expected': expected, 'paid': paid, 'remaining': remaining, 'overdueContracts': overdueContracts};
  }


  Future<Map<String, int>> livePortfolioSummary() async {
    final propertiesCount = await count('properties');
    final unitRows = await database.rawQuery("SELECT COUNT(*) total, SUM(CASE WHEN status = 'مؤجرة' THEN 1 ELSE 0 END) occupied FROM units");
    final tenantsCount = await count('tenants');
    final activeContracts = await database.rawQuery("SELECT COUNT(*) c FROM contracts WHERE status = 'نشط'");
    return {
      'properties': propertiesCount,
      'units': (unitRows.first['total'] as num?)?.toInt() ?? 0,
      'occupied': (unitRows.first['occupied'] as num?)?.toInt() ?? 0,
      'tenants': tenantsCount,
      'activeContracts': (activeContracts.first['c'] as num?)?.toInt() ?? 0,
    };
  }

  Future<List<Map<String, Object?>>> recentPayments({int limit = 5}) async => database.rawQuery('''
    SELECT pay.*, t.name AS tenant_name, u.number AS unit_number, p.name AS property_name
    FROM payments pay
    LEFT JOIN contracts c ON c.id = pay.contract_id
    LEFT JOIN tenants t ON t.id = c.tenant_id
    LEFT JOIN units u ON u.id = c.unit_id
    LEFT JOIN properties p ON p.id = u.property_id
    ORDER BY pay.id DESC LIMIT ?
  ''', [limit]);

  Future<List<Map<String, Object?>>> expiredContracts({int limit = 100}) async {
    final today = DateTime.now().toIso8601String().substring(0, 10);
    return database.rawQuery('''
      SELECT c.*, t.name AS tenant_name, u.number AS unit_number, p.name AS property_name
      FROM contracts c
      LEFT JOIN tenants t ON t.id = c.tenant_id
      LEFT JOIN units u ON u.id = c.unit_id
      LEFT JOIN properties p ON p.id = u.property_id
      WHERE date(c.end_date) < date(?) AND c.status != 'ملغي'
      ORDER BY date(c.end_date) DESC LIMIT ?
    ''', [today, limit]);
  }

  Future<List<Map<String, Object?>>> expiringContracts({int days = 30, int limit = 5}) async {
    final today = DateTime.now();
    final until = today.add(Duration(days: days));
    return database.rawQuery('''
      SELECT c.*, t.name AS tenant_name, u.number AS unit_number, p.name AS property_name
      FROM contracts c
      LEFT JOIN tenants t ON t.id = c.tenant_id
      LEFT JOIN units u ON u.id = c.unit_id
      LEFT JOIN properties p ON p.id = u.property_id
      WHERE c.status = 'نشط' AND date(c.end_date) BETWEEN date(?) AND date(?)
      ORDER BY date(c.end_date) ASC LIMIT ?
    ''', [today.toIso8601String().substring(0,10), until.toIso8601String().substring(0,10), limit]);
  }


  int _monthsInRange(DateTime start, DateTime end) {
    if (end.isBefore(start)) return 0;
    return (end.year - start.year) * 12 + end.month - start.month + 1;
  }

  Future<Map<String, Object>> financialReport({required String startDate, required String endDate, int? propertyId}) async {
    final start = DateTime.tryParse(startDate) ?? DateTime(DateTime.now().year, DateTime.now().month, 1);
    final end = DateTime.tryParse(endDate) ?? DateTime.now();
    final contracts = await database.rawQuery('''
      SELECT c.*, u.number AS unit_number, u.property_id, p.name AS property_name, t.name AS tenant_name
      FROM contracts c
      JOIN units u ON u.id = c.unit_id
      LEFT JOIN properties p ON p.id = u.property_id
      LEFT JOIN tenants t ON t.id = c.tenant_id
      WHERE c.status != 'ملغي' ${propertyId == null ? '' : 'AND u.property_id = ?'}
      ORDER BY c.id DESC
    ''', propertyId == null ? [] : [propertyId]);
    var expected = 0, paid = 0;
    final details = <Map<String,Object?>>[];
    for (final c in contracts) {
      final cs = DateTime.tryParse(c['start_date']?.toString() ?? '');
      final ce = DateTime.tryParse(c['end_date']?.toString() ?? '') ?? end;
      if (cs == null) continue;
      final contractStart = cs;
      final contractEnd = ce;
      final months = _installmentsInRange(contractStart, contractEnd, start, end);
      final rent = (c['rent'] as num?)?.toInt() ?? 0;
      final expectedForContract = rent * months;
      final payments = await database.rawQuery('''
        SELECT COALESCE(SUM(amount),0) total FROM payments
        WHERE contract_id = ? AND date(date) BETWEEN date(?) AND date(?)
      ''', [c['id'], startDate, endDate]);
      final paidForContract = (payments.first['total'] as num?)?.toInt() ?? 0;
      final remaining = (expectedForContract - paidForContract).clamp(0, 1 << 60);
      expected += expectedForContract;
      paid += paidForContract;
      details.add({...c, 'expected': expectedForContract, 'paid': paidForContract, 'remaining': remaining, 'months': months});
    }
    final expenseRows = await database.rawQuery('''
      SELECT COALESCE(SUM(e.amount),0) total FROM expenses e
      WHERE date(e.date) BETWEEN date(?) AND date(?) ${propertyId == null ? '' : 'AND e.property_id = ?'}
    ''', propertyId == null ? [startDate, endDate] : [startDate, endDate, propertyId]);
    final revenueRows = await database.rawQuery('''
      SELECT COALESCE(SUM(r.amount),0) total FROM revenues r
      WHERE date(r.date) BETWEEN date(?) AND date(?) ${propertyId == null ? '' : 'AND r.property_id = ?'}
    ''', propertyId == null ? [startDate, endDate] : [startDate, endDate, propertyId]);
    final expenses = (expenseRows.first['total'] as num?)?.toInt() ?? 0;
    final revenues = (revenueRows.first['total'] as num?)?.toInt() ?? 0;
    return {'expected': expected, 'paid': paid, 'remaining': (expected-paid).clamp(0, 1 << 60), 'expenses': expenses, 'revenues': revenues, 'net': paid + revenues - expenses, 'contracts': details};
  }

  Future<Map<String, Object>> propertyReport({required int propertyId, required String startDate, required String endDate}) async {
    final propertyRows = await database.query('properties', where: 'id = ?', whereArgs: [propertyId], limit: 1);
    if (propertyRows.isEmpty) throw StateError('العقار غير موجود');
    final property = propertyRows.first;
    final start = DateTime.tryParse(startDate) ?? DateTime(DateTime.now().year, DateTime.now().month, 1);
    final end = DateTime.tryParse(endDate) ?? DateTime.now();
    final unitRows = await database.rawQuery("""
      SELECT u.id, u.number, u.rent, u.status,
             c.id AS contract_id, c.rent AS contract_rent, c.status AS contract_status,
             c.start_date, c.end_date, t.name AS tenant_name, t.phone AS tenant_phone, t.identity AS tenant_identity
      FROM units u
      LEFT JOIN contracts c ON c.unit_id = u.id AND c.status != 'ملغي'
      LEFT JOIN tenants t ON t.id = c.tenant_id
      WHERE u.property_id = ?
      ORDER BY CAST(u.number AS INTEGER), u.number
    """, [propertyId]);
    var expected = 0, paid = 0;
    final units = <Map<String, Object?>>[];
    for (final u in unitRows) {
      final contractId = (u['contract_id'] as num?)?.toInt();
      var unitExpected = 0;
      var unitPaid = 0;
      var months = 0;
      if (contractId != null) {
        final cs = DateTime.tryParse(u['start_date']?.toString() ?? '');
        final ce = DateTime.tryParse(u['end_date']?.toString() ?? '') ?? end;
        if (cs != null) {
          months = _installmentsInRange(cs, ce, start, end);
          unitExpected = ((u['contract_rent'] ?? u['rent'] ?? 0) as num).toInt() * months;
        }
        final payRows = await database.rawQuery("""
          SELECT COALESCE(SUM(amount),0) total FROM payments
          WHERE contract_id = ? AND date(date) BETWEEN date(?) AND date(?)
        """, [contractId, startDate, endDate]);
        unitPaid = (payRows.first['total'] as num?)?.toInt() ?? 0;
      }
      final remaining = (unitExpected - unitPaid).clamp(0, 1 << 60);
      expected += unitExpected; paid += unitPaid;
      units.add({...u, 'expected': unitExpected, 'paid': unitPaid, 'remaining': remaining, 'months': months});
    }
    final expenses = await database.query('expenses', where: 'property_id = ? AND date(date) BETWEEN date(?) AND date(?)', whereArgs: [propertyId, startDate, endDate], orderBy: 'date DESC, id DESC');
    final revenues = await database.query('revenues', where: 'property_id = ? AND date(date) BETWEEN date(?) AND date(?)', whereArgs: [propertyId, startDate, endDate], orderBy: 'date DESC, id DESC');
    final expenseTotal = expenses.fold<int>(0, (sum, row) => sum + ((row['amount'] as num?)?.toInt() ?? 0));
    final revenueTotal = revenues.fold<int>(0, (sum, row) => sum + ((row['amount'] as num?)?.toInt() ?? 0));
    return {
      'property': property,
      'units': units,
      'expensesList': expenses,
      'revenuesList': revenues,
      'expected': expected,
      'paid': paid,
      'remaining': (expected - paid).clamp(0, 1 << 60),
      'expenses': expenseTotal,
      'revenues': revenueTotal,
      'net': revenueTotal - expenseTotal,
      'cashNet': paid + revenueTotal - expenseTotal,
      'overdueUnits': units.where((u) => ((u['remaining'] as num?)?.toInt() ?? 0) > 0).length,
    };
  }

  Future<int> count(String table) async {final r=await database.rawQuery('SELECT COUNT(*) c FROM $table');return (r.first['c'] as int?)??0;}
  Future<int> sum(String table,String column) async {final r=await database.rawQuery('SELECT COALESCE(SUM($column),0) total FROM $table');return ((r.first['total'] as num?)??0).toInt();}
}
